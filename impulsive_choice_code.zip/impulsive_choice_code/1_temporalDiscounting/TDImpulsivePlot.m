
%code tests different transition probabilities and reward sizes and looks
%at effects on impulsivity


clear;


%% option for original or db code:
original=0;


%% (1) delayed reward with and without probabilistic payout (additional uncertainty)

R1 = 1; %impuslive reward
R2 = 1 : 0.1 : 50; %delayed reward size

beta = 1; %defining transition probability at t=0 ( p(progressing to next state)= 1-beta*delta
delta = 0.7 : 0.01 : 0.99;
T = 10; %delay

aT = 0 : 0.01 : T;

%reward values, sort of?
Q1 = R1; %immediate reward value, not accounting for transition probability at t=0
Q2 = R2'*beta*(delta.^T); %delayed reward values for different reward magnitudes and deltas (size= nreward sizes x ndeltas)

dQ = (Q2 - Q1)'; %difference in reward values (size= ndeltas x nreward sizes)

for ri = 1 : size(dQ, 1)
    
    mi = find(dQ(ri, :) > 0); %for 1 delta, find all idx of values bigger than 0
    %dQ(ri, mi) should be value differences greater than 0 in favor of NOT impulsive choice
    %first mi index value is the number of impulsive choices made
    
    if ~isempty(mi)
        fi(ri) = mi(1); %fi(loop index)=first idx of value bigger than 0, which reps the # of impulsive choices made!
    end
end

%added by DCB:
%instead of number of impulsive choices, we can plot the fraction out ofthe total number of choices made for each delta value
nRewardSizes=length(R2);
nChoicesMade=nRewardSizes;
figure(1); set(gcf,'Color',[1 1 1])
%subplot(2,2,1);
plot(1-delta,fi/nChoicesMade,'k*-'); hold on
xlabel('Uncertainty (1 - delta)');
ylabel('Proportion of impulsive choices');

%original plot:
if original==1
    figure(2)
    subplot(2,2,1);
    plot(1-delta, fi,'k*-'); %1-delta= transition probability to next state
    xlabel('Uncertainty (1 - delta)');
    ylabel('Number of impulsive choices');
end


%%%%%%%%%%%%%%%%%%%%% added by DCB:
%what if R2s were probabilistic- should look the same as increased delta to drive impulsivity

% try to model this with using delta for T-1. Then different probability
% for final state to model probabilistic reward (this would be exit)

%line colors
linecolors= [1 0 0; ... %red
    1, 0.5, 0; ... %orange
    0.9, 0.9, 0.3; ... %dark yellow
    0, 1, 0; ... %green
    0, 1, 1; ... %cyan
    0, 0, 1; ...%blue
    0.494, 0.184, 0.556; ... %purple
    1, 0.5, 0.6; ... %pink
    0.2, 0, 0]; %brown


probabilisticRewards= 0.1:0.1:0.9 ;

for i=1:length(probabilisticRewards)
    %pDelayedReward=0.5;
    pDelayedReward=probabilisticRewards(i);
    
    %reward values, sort of? :
    Q1 = R1; %immediate reward value, not accounting for transition probability at t=0
    Q2 = R2'*beta*(delta.^(T-1))*pDelayedReward; %delayed reward values for different reward magnitudes and deltas (size= nreward sizes x ndeltas)
    
    dQ2 = (Q2 - Q1)'; %difference in reward values (size= ndeltas x nreward sizes)
    
    for ri2 = 1 : size(dQ2, 1)
        
        mi2 = find(dQ2(ri2, :) > 0); %for 1 delta, find all idx of values bigger than 0
        %dQ(ri, mi) should be value differences greater than 0 in favor of NOT impulsive choice
        %first mi index value is the number of impulsive choices made
        if ~isempty(mi2)
            fi2(ri2) = mi2(1); %fi(loop index)=first idx of value bigger than 0, which reps the # of impulsive choices made!
        end
    end
    
    nRewardSizes=length(R2);
    nChoicesMade=nRewardSizes;
    figure(1); hold on
    %subplot(2,2,1);
    plot(1-delta,fi2/nChoicesMade,'-','Color',linecolors(i,:))
    
    xlabel('Uncertainty (1 - delta)');
    ylabel('Proportion of impulsive choices');
    %legend('det. delayed reward', strcat('p=',num2str(pDelayedReward), ' delayed reward'))
    
    Legend{i+1}=strcat('R2 p= ', num2str(pDelayedReward));
end
Legend{1}='determ. R2';
legend(Legend)

%% (2) subjective value curves over time with and without probabilistic reward (additional uncertainty)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
T = 10; %delay
aT = 0 : 0.01 : T; %discretized time delay

if original==1
    %original
    figure(2); hold on
    subplot(2,2,2);
    diCtr = 1;
    for di = 0.7 : 0.1 : 0.9
        discountCurves(diCtr, :) = di.^aT;
        diCtr = diCtr + 1;
    end
    
    plot(aT, discountCurves);
    xlabel('Time');
    ylabel('Subjective Value');

elseif original==0
    %original, no probabilistic reward, 3 different deltas for decay of
    %subjective value with time:
    figure(2); 
	set(gcf,'Color',[1 1 1])
    diCtr = 1;
    for di = 0.7 : 0.1 : 0.9
        discountCurves(diCtr, :) = di.^aT;
        diCtr = diCtr + 1;
    end   
    plot(aT, discountCurves,'k-'); hold on
    xlabel('Time');
    ylabel('Subjective Value');
    
    probabilisticRewards= 0.1:0.2:0.9;   
    diCtr=1;
    for di = 0.7 : 0.1 : 0.9
        for pr=1:length(probabilisticRewards)
            pDelayedReward=probabilisticRewards(pr);
            discountCurvesPR2(diCtr,pr,:)= pDelayedReward*(di.^(aT)); 
            
            singleDiscountCurvePR2(diCtr,:)=pDelayedReward*(di.^(aT));
            figure(2)
            plot(aT, singleDiscountCurvePR2,'--','Color',linecolors(pr,:),'LineWidth',1.5); hold on
        end
        
        diCtr = diCtr + 1;
    end
    
end


%% (3) subject's world view vs. environment uncertainty

T = 15; %delay
clearvars dQ Q2 Q1
if original==1
    
    %second reward not probabilistic, only temporal discounting
    
    subjectV = [0.6 0.8]; %Delta subject. Uncertainty (1 - delta) [hi low]d
    worldV   = [0.6 0.8];
    
    R2=5:1:75;
    
    Q1 = R1;
    Q2 = R2'*beta*(subjectV.^T);
    dQ = (Q2 - Q1);
    
    %%% choose bigger option
    chQ = dQ > 0;
    
    clearvars tR
    for vi = 1 : 2
        
        ch1 = find(chQ(:, vi) == 0);
        ch2 = find(chQ(:, vi) == 1);
        
        choices_vi(vi,:)=[length(ch1), length(ch2)]
        
        tR(vi, 1) = length(ch1)*R1 + sum(R2(ch2)*beta*(worldV(1)^T));
        tR(vi, 2) = length(ch1)*R1 + sum(R2(ch2)*beta*(worldV(2)^T));
        
    end
    
    figure(200); hold on
    %subplot(2,2,3); 
    set(gcf,'Color',[1 1 1]); set(gca,'fontsize',14)
    bar(tR');
    legend('Impulsive Subject', 'Patient Subject');
    xticks([1,2])
    set(gca, 'XtickLabel', {'Unstable Environment', 'Stable Environment'});
    ylabel('Total Reward');
    
    
    clearvars tR
    T = 9;
    subjectV = [0.65 0.8];
    worldV   = [0.65 0.8];
    
    R2 =  5 : 1 : 50;
    
    Q1 = R1;
    Q2 = R2'*beta*(subjectV.^T);
    dQ = (Q2 - Q1);
    
    %%% choose option 2
    chQ = dQ > 0;
    
    for vi = 1 : 2
        
        ch1 = find(chQ(:, vi) == 0);
        ch2 = find(chQ(:, vi) == 1);
        
        tR(vi, 1) = length(ch1)*R1 + sum(R2(ch2)*beta*(worldV(1)^T));
        tR(vi, 2) = length(ch1)*R1 + sum(R2(ch2)*beta*(worldV(2)^T));
        
    end
    
    figure(2); hold on
    subplot(2,2,4);
    bar(tR');
    % legend('Impulsive Subject', 'Patient Subject');
    set(gca, 'XtickLabel', {'Unstable Environment', 'Stable Environment'});
    ylabel('Total Reward');
    

elseif original==0
    
    delta_subjectV = [0.5:0.1:0.9]; %Delta subject. Uncertainty (1 - delta). operating close to random to expecting near full return
    worldV   = [0.5:0.1:0.9]; %random to low risk
    
    %R2 = 5 : 1 : 40; %original range (36 decisions)
    
    %R2 = 5 : 1 : 100; %(larger range, 96 decisions)
    
    %R2=5:0.1:8.5; %smaller range, same number of decisions as original , 36
    
    R2=5:1:75;
    
    %R2= 5:5:100; %larger range, fewer decisions (20) 
           
    Q1 = R1;
    
    %R2 not probabilistic bc that would just add to world uncertainty
    Q2 = R2'*beta*(delta_subjectV.^(T)); %discounted choice2 values
    dQ = (Q2 - Q1);
    
    %%% choose bigger option:
    chQ = dQ > 0;
    
    for vi = 1 : size(chQ,2)
        
        ch1 = find(chQ(:, vi) == 0);
        ch2 = find(chQ(:, vi) == 1);
        
        tR(vi, 1) = length(ch1)*R1 + sum(R2(ch2)*beta*(worldV(1)^T));
        tR(vi, 2) = length(ch1)*R1 + sum(R2(ch2)*beta*(worldV(2)^T));
        tR(vi, 3) = length(ch1)*R1 + sum(R2(ch2)*beta*(worldV(3)^T));
        tR(vi, 4) = length(ch1)*R1 + sum(R2(ch2)*beta*(worldV(4)^T));
        tR(vi, 5) = length(ch1)*R1 + sum(R2(ch2)*beta*(worldV(5)^T));
    end
    

    figure(3); hold on
    %plot
    bar(tR'); set(gcf,'Color',[1 1 1])
    %set(gca, 'XtickLabel', {'Unstable Environment', 'Stable Environment'});
    xticks([1:5]);
    xl=xlabel('Environment stability'); xl.FontSize = 14;
    xticklabels({'0.5','0.6','0.7','0.8','0.9'})
    yl=ylabel('Total Reward');  yl.FontSize = 14;
    lgd=legend('subject patience=0.5','0.6','0.7','0.8','0.9');
    lgd.FontSize = 14;
    
    %same as fig 3 but plotting % of max reward instead of raw reward:
    figure(4); hold on
    tpR=tR*100/sum(R2);
    bar(tpR'); set(gcf,'Color',[1 1 1])
    xticks([1:5]);
    xl=xlabel('Environment stability'); xl.FontSize = 14;
    xticklabels({'0.5','0.6','0.7','0.8','0.9'})
    yl=ylabel('Percent of Max Possible Reward');  yl.FontSize = 14;
    lgd=legend('subject patience=0.5','0.6','0.7','0.8','0.9');
    lgd.FontSize = 14;
    ylim([0,35]); yticks([0:2:35])
    
    
end

%% (4)Simulating performance for agents with high and low discount factors in low and high uncertainty environments (old way, not separating df and delta)
%9.15.21

% R1=1:0.5:51; %define immediate rewards- always smaller
% R2=5:1:105;
% Trange=[1,20]; %range of times, too short or too small effect goes away
% 
% niter=10; %iterations over 101 trials, varying delay
% ntrials=length(R2);
% 
% dfs= [0.6 0.99];
% beta=1;
% deltas= [0.6 0.99]; %low & high uncertainty (cross for agents)
% 
% trackChoices_highC=zeros(length(dfs),niter,ntrials); %keep track of choice behavior
% trackChoices_lowC=zeros(length(dfs),niter,ntrials); %keep track of choice behavior
% 
% for iter=1:niter
%     Ts= Trange(1) + (Trange(2)-Trange(1)).*rand(1,length(R2)); %r = a + (b-a).*rand(N,1)
%     Ts=round(sort(Ts));
%     
%     
%     for t=1:ntrials
%         delay=Ts(t);
%         r1=R1(t);
%         r2=R2(t);
%         
%         q1=r1;
%         
%         q2s = R2(t)*beta*(dfs.^(delay)); %compute action value for both agents at the same time
% 
%         
%         
%         choices=q2s>q1; %choices for both agents-- action 2 if 1, otherwise 0
%         choices=double(choices)+1;
%         
%         %Compute single trial state-action values for only action (at t=0) : choose r1 or r2
%         %based on "subject view" high or low d.f.
% 
%         
%         for agent=1:2
%             if choices(agent)==1
%                 %agent gets r1
%                 
%                 %low certainty env (0.6):
%                 outcome_lowC(t,agent)=r1;
%                 
%                 %high certainty env (0.99):
%                 outcome_highC(t,agent)=r1;
%                 
%                 
%             elseif choices(agent)==2
%                 %agent proceeds towards r2
%                 %Then sim the outcome based on time the transition probabilities to receive the reward r2 or nothing if r2 was chosen:
%                 %Do this for low and high d.f. to represent true "world views"
%                 %matching or mismatching the "subject view"
%                 
%                 for d=1:length(deltas)
%                     % for low certainty then high certainty
%                     y = zeros(Ts(t),1);
%                     x = rand(Ts(t),1);
%                     y(x<= deltas(d)) = 1;
%                     
%                     loss=find(y==0);
%                     if isempty(loss)
%                         %outcome = r2
%                         reward=r2;
%                     elseif length(loss)>=1
%                         %outcome=0
%                         reward=0;                       
%                     end
%                     
%                     if d==1
%                         outcome_lowC(t,agent)=reward;
%                     elseif d==2
%                         outcome_highC(t,agent)=reward;
%                     end
%                     
%                 end
%                 
%             end
%         end
%         
%     end
%     
%     meanReward_lowC(iter,:)= mean(outcome_lowC);
%     meanReward_highC(iter,:)= mean(outcome_highC);
% 
% end
% 
% %Mean reward for low and high certainty for the two agents
% 
% avgRewardIter_lowC= mean(meanReward_lowC);
% avgRewardIter_highC= mean(meanReward_highC);
% 
% stderrRewardIter_lowC= stderr(meanReward_lowC);
% stderrRewardIter_highC= stderr(meanReward_highC);
% 
% 
% meanReward=[avgRewardIter_highC',avgRewardIter_lowC'];
% stderrRew=[stderrRewardIter_highC, stderrRewardIter_lowC];

%% (5)Simulating performance for agents with high and low discount factors in low and high uncertainty environments (new way, df and delta)
%05.06.22
clear

R1=1:0.5:51; %define immediate rewards- always smaller
R2=5:1:105;
Trange=[1,20]; %range of times, too short or too small effect goes away

niter=10; %iterations over 101 trials, varying delay
ntrials=length(R2);

%works:
% dfs= [0.6 0.99];
% beta=1;
% deltas= [0.4 0.99]; %low & high uncertainty (cross for agents)

%also works:
dfs= [0.6 0.99];
beta=1;
deltas= [0.55 0.99]; %low & high uncertainty (cross for agents)

trackChoices_highC=zeros(length(dfs),niter,ntrials); %keep track of choice behavior
trackChoices_lowC=zeros(length(dfs),niter,ntrials); %keep track of choice behavior

deltapairs=[fliplr(deltas); deltas];
R2=R2*10;

for condit=1:2
    %delta_agent > delta_env (low/uncertain environment) condit=1
    %delta_agent < delta_env (high certain environment) condit=2

    delta_agent=deltapairs(condit,1);
    delta_env=deltapairs(condit,2);

    for iter=1:niter
        Ts= Trange(1) + (Trange(2)-Trange(1)).*rand(1,length(R2)); %r = a + (b-a).*rand(N,1)
        Ts=round(sort(Ts)); %longer delays for larger rewards

        for t=1:ntrials
            delay=Ts(t);
            r1=R1(t);
            r2=R2(t);

            q1=r1;

            q2s = R2(t)*beta*(dfs.^(delay))*(delta_agent^(delay)); %compute action value for both agents at the same time

            choices=q2s>q1; %choices for both agents-- action 2 if 1, otherwise 0
            choices=double(choices)+1;

            %Compute single trial state-action values for only action (at t=0) : choose r1 or r2
            %based on "subject view" high or low d.f.
            for agent=1:2
                if choices(agent)==1
                    %agent gets r1

                    if condit==1
                        %low certainty env (0.6):
                        outcome_lowC(t,agent)=r1;
                    elseif condit==2
                        %high certainty env (0.99):
                        outcome_highC(t,agent)=r1;
                    end


                elseif choices(agent)==2
                    %agent proceeds towards r2
                    %Then sim the outcome based on time the transition probabilities to receive the reward r2 or nothing if r2 was chosen:
                    %Do this for low and high d.f. to represent true "world views"
                    %matching or mismatching the "subject view"

                    % for low certainty then high certainty by condit
                    y = zeros(Ts(t),1);
                    x = rand(Ts(t),1); %length of n bernoulli trials
                    y(x<= delta_env) = 1;

                    loss=find(y==0);
                    if isempty(loss)
                        %outcome = r2
                        reward=r2;
                    elseif length(loss)>=1
                        %outcome=0
                        reward=0;
                    end

                    if condit==1
                        outcome_lowC(t,agent)=reward;
                    elseif condit==2
                        outcome_highC(t,agent)=reward;
                    end
                end
            end
            
            %save choices
            if condit==1
                choices_lowC(t,:)=choices;
            elseif condit==2
                choices_highC(t,:)=choices;
            end
        end

        if condit==1
            meanReward_lowC(iter,:)= mean(outcome_lowC);

            %prop picked delayed option:
            choiceProp_agent1=length(find(choices_lowC(:,1)==2))/length(choices_lowC);
            choiceProp_agent2=length(find(choices_lowC(:,2)==2))/length(choices_lowC);
            propChoseLarger_lowC(iter,:)= [choiceProp_agent1, choiceProp_agent2];

        elseif condit==2
            meanReward_highC(iter,:)= mean(outcome_highC);

            %prop picked delayed option:
            choiceProp_agent1=length(find(choices_highC(:,1)==2))/length(choices_highC);
            choiceProp_agent2=length(find(choices_highC(:,2)==2))/length(choices_highC);
            propChoseLarger_highC(iter,:)= [choiceProp_agent1, choiceProp_agent2];
        end

    end
end

%Mean reward for low and high certainty for the two agents
avgRewardIter_lowC= mean(meanReward_lowC);
avgRewardIter_highC= mean(meanReward_highC);
stderrRewardIter_lowC= stderr(meanReward_lowC);
stderrRewardIter_highC= stderr(meanReward_highC);
meanReward=[avgRewardIter_highC',avgRewardIter_lowC'];
stderrRew=[stderrRewardIter_highC, stderrRewardIter_lowC]; %[HIC/lowdf, hi df, LOWC/low df, hi df]

%Avg proportion of trials picked delayed option:
avgChoiceIter_lowC= mean(propChoseLarger_lowC);
avgChoiceIter_highC= mean(propChoseLarger_highC);
stderrChoiceIter_lowC= stderr(propChoseLarger_lowC);
stderrChoiceIter_highC= stderr(propChoseLarger_highC);
meanChoiceProp= [avgChoiceIter_highC',avgChoiceIter_lowC'];
stderrChoiceProp=[stderrChoiceIter_highC, stderrChoiceIter_lowC];

% mean reward:
figure(); hold on
    %plot
    bar(meanReward' ); set(gcf,'Color',[1 1 1]); hold on
    set(gca, 'XtickLabel', {'Certain', 'Uncertain'});
    xticks([1:2]);
    xl=xlabel('Environment stability'); xl.FontSize = 14;
    yl=ylabel('Average Reward (10 iterations of 100 trials with variable delays)');  yl.FontSize = 14;
    lgd=legend(strcat('d.f.=',num2str(dfs(1))),strcat('d.f.=',num2str(dfs(2))));
    set(gca,'FontSize',14)
    errorbar([0.85 1.15 1.85, 2.15],[avgRewardIter_highC, avgRewardIter_lowC],stderrRew,'k','LineWidth',2,'LineStyle','none')
    ylim([0 70])


    % avg choice of delayed opt:
figure(); hold on
    %plot
    bar(meanChoiceProp' ); set(gcf,'Color',[1 1 1]); hold on
    set(gca, 'XtickLabel', {'World Certain', 'World Uncertain'});
    xticks([1:2]);
    xl=xlabel('Environment stability'); xl.FontSize = 14;
    yl=ylabel('Average Proportion picked delayed option');  
    yl.FontSize = 14;
    lgd=legend(strcat('d.f.=',num2str(dfs(1))),strcat('d.f.=',num2str(dfs(2))));
    set(gca,'FontSize',14)
    errorbar([0.85 1.15 1.85, 2.15],[avgChoiceIter_highC, avgChoiceIter_lowC],stderrChoiceProp,'k','LineWidth',2,'LineStyle','none')
    %ylim([0 1])

%% statistical testing: paired sample t-tests

%Reward:
%certain environment:
[hc, pc, ci, stats1]= ttest(meanReward_highC(:,1),meanReward_highC(:,2));

%uncertain environment:
[huc, puc, ci, stats2]= ttest(meanReward_lowC(:,1),meanReward_lowC(:,2));

%Choices:
[hc_choice, pc_choice, ci, stats3]= ttest(propChoseLarger_highC(:,1),propChoseLarger_highC(:,2));
[huc_choice, puc_choice,ci,stats4]= ttest(propChoseLarger_lowC(:,1),propChoseLarger_lowC(:,2));


%% Training agents to learn discount factors based on rewards 3.29.2021


if 0
%low-uncertainty (delayed reward not probabilistic, discount factor should grow with more trials)
%high-uncertainty (d.f. should fluctuate and settle to match level of uncertainty)
clear

%initialize:
stepSize=0.05; %0.05 works better for starting lo and ending hi, 0.02 better for starting hi and decr

delta_subjectVo = 0.75; %Delta subject at start of fit. Uncertainty (1 - delta). 
delta_subjectV=delta_subjectVo;
dfSubject(1)=delta_subjectV;

worldV= 0.99; %0.5 (volatile)->0.99 (low uncertainty)

err(1)=1; %initial error
agentFitness=0; %initial agent fitness
fitness(1)=agentFitness;

theta_o=0; %initial change in deltaSubj
theta(1)=theta_o;

iter=1;

%while err(iter)~= 0
while abs(err(iter)) > 0.001 
    
    %delta_subjectV= delta_subjectV + theta(iter);
    


    %dfSubject(iter)=delta_subjectV;
    %fitness(iter)=agentFitness;
    
    R1=1;
    beta=1;
    T=10;   
    R2=5:1:75;           
    Q1 = R1;
    
    %R2 not probabilistic bc that would just add to world uncertainty
    Q2 = R2'*beta*(delta_subjectV.^(T)); %discounted choice2 values
    dQ = (Q2 - Q1);
    
    %%% agent chooses bigger option:
    chQ = dQ > 0;
    ch1 = find(chQ== 0);
    ch2 = find(chQ== 1);   
    tR = length(ch1)*R1 + sum(R2(ch2)*beta*(worldV^T)); %Total Reward outcome of agent's discounting and choices
    
    %now do the same for the "world" and compare outcomes:
    Q2W = R2'*beta*(worldV.^(T)); %discounted choice2 values based on world uncertainty
    dQW = (Q2W - Q1);
    chQW = dQW > 0;
    ch1W = find(chQW== 0);
    ch2W = find(chQW== 1);    
    possibleMaxReward= length(ch1W)*R1 + sum(R2(ch2W)*beta*(worldV^T));
    
    agentFitness= tR/possibleMaxReward;
    
    iter=iter+1;
    err(iter)= 1-agentFitness;
    improvement=err(iter-1)-err(iter);
    
    if iter==2
        %bump in theta based on difference btwn world and subjv for first
        %step (could make random so it's a dumber start)
        df=delta_subjectVo-worldV;
        if df>0
            pn=-1;
        else
            pn=1;
        end
    else
        if improvement>0
            %decreased error, do the same thing
            pn=-1;
        elseif improvement < 0 
            %increased error, do the opposite thing
            pn=1;
        elseif improvement==0
            v=[-1,1];
            pn = v(randperm(length(v),1));
            %stepSize=stepSize/2;
        end
    end
 
    theta(iter)=theta(iter-1) + pn*stepSize;
    delta_subjectV= delta_subjectV + theta(iter);
    if delta_subjectV> 1.0
        delta_subjectV=1.0;
    elseif delta_subjectV < 0.5
        delta_subjectV=0.5;
    end
    
    
    dfSubject(iter)=delta_subjectV;
    fitness(iter)=agentFitness;

end

%
figure(5)
set(gcf,'Color',[1 1 1])
subplot(1,2,1)
plot(1,delta_subjectVo,'rs','MarkerSize',14,'MarkerFaceColor','r');hold on
plot(iter,worldV,'gs','MarkerSize',14,'MarkerFaceColor','g')
plot(1:iter,dfSubject,'b*-'); 
plot(iter,dfSubject(end),'bd','MarkerSize',14,'MarkerFaceColor','b')
agentlegendS=strcat('agent starting d.f.','{ }', num2str(delta_subjectVo));
worldlegend=strcat('world uncertainty','{ }', num2str(worldV));
agentlegendF=strcat('agent final d.f.','{ }', num2str(delta_subjectV));
legend(agentlegendS, worldlegend,'training agent d.f.',agentlegendF);
set(gca,'fontsize',14)
xlabel('iteration')
ylabel('delta')
title ('Discounting')
xlim([0 iter])
    
subplot(1,2,2)
plot(1:iter,fitness,'r*-'); hold on
set(gca,'fontsize',14)
xlabel('iteration')
ylabel('agent fitness (totalReward/possibleReward)')
title ('Agent fitness')
xlim([0 iter])

end
