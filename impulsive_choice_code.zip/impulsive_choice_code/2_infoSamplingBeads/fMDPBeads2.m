

%beads task
%3 actions: choose blue urn, choose green urn, draw another
%uncertainty in this task refers to reliability of draw, that it's predictive of the majority
clear

q=0.8; %fraction of beads in majority urn
maxDraws=10;
Ntrials=300;
drawSequence = generateDrawSequences(q, maxDraws, Ntrials);
R.correct=10; %reward 
R.error= -10; %cost of error  
R.q=q; %another place where q is defined?
R.sample= -0.2; %cost to sample
gamma=1; %discounting (1=none)
partialUpdate=1; % partialUpdate=1 no uncertainty around draws

[reward, choiceTimes,Qsat] = backWardInductionDB(Ntrials, maxDraws, drawSequence, R, gamma ,partialUpdate);

avgPercentOfMaxReward= (sum(reward)/Ntrials)*100/R.correct;
avgNumDrawsBeforeChoice=mean(choiceTimes);

%% (1) how majority urn prob. affects reward and # of draws before choice of ideal observer

if 0
    clearvars
    linecolors= [1 0 0; ... %red
        1, 0.5, 0; ... %orange
        0.9, 0.9, 0.3; ... %dark yellow
        0, 1, 0; ... %green
        0, 1, 1; ... %cyan
        0, 0, 1; ...%blue
        0.494, 0.184, 0.556; ... %purple
        1, 0.5, 0.6; ... %pink
        0.2, 0, 0]; %brown
    
    qs=0.55:0.05:0.9;
    %costs=-0.05:-0.1:-0.9;
    costs=-0.005:-0.05:-0.405;
    gamma=1.0; %discount factor 1=no discounting
    
    for c=1:length(costs)
        for i=1:length(qs)
            q=qs(i);
            maxDraws=12;
            Ntrials=100;
            drawSequence = generateDrawSequences(q, maxDraws, Ntrials);
            R.correct=10; %reward
            R.error= -10; %cost of error
            R.q=q; %another place where q is defined?
            R.sample= costs(c); %cost to sample
            partialUpdate=1.0;
            [reward, choiceTimes,Qsat] = backWardInductionDB(Ntrials, maxDraws, drawSequence, R,gamma,partialUpdate);
            avgPercentOfMaxReward(i)= (sum(reward)/Ntrials)*100/R.correct;
            avgNumDrawsBeforeChoice(i)=mean(choiceTimes);
        end
        figure(1); set(gcf,'Color',[1 1 1])
        plot(qs,avgPercentOfMaxReward,'o-','Color',linecolors(c,:),'LineWidth',1.5); hold on;
        ylabel('avg % of max reward'); xlabel('fraction of beads in majority urn'); hold on
        
        figure(2);set(gcf,'Color',[1 1 1])
        plot(qs,avgNumDrawsBeforeChoice,'o-','Color',linecolors(c,:),'LineWidth',1.5); hold on;
        ylabel('avg # of draws before choice'); xlabel('fraction of beads in majority urn'); hold on
        ylim([1 maxDraws])
        
    end
    
    for iter=1:length(costs)
        Legend{iter}=strcat('cost', num2str(costs(iter)));
    end
    figure(1);legend(Legend)
    figure(2);legend(Legend)
    
end
%% (2) additional uncertainty through partial updating
 %for partial updating, change partialUpdate parameter and re-run (1) 
 
 
%% (3) info sampling with discount factor (exponential cost for time)

 if 0
     gamma=1; %gamma discounting comes in at action value calculation
 end
 %Q(s_t,a)= r_t(s_t,a) + sum( gamma * p_t(j|s,a) * u_t+1(j))


%% (4) two situations where having different discount factors is optimal
% situation 1: doesn't pay to sample (high discounting better, smaller gamma)
% siutation 2: valuable to sample a lot (low discounting better, bigger gamma)
clear
clearvars

%Situation 1: (certain environment)
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
tic
gammaRange=[0.55, 0.99]; 
R.correct=10; %reward
R.error= -12; %cost of error
R.sample= -0.1; %cost to sample
q=0.55; %fraction of beads in majority urn (usually for making draws & model, but here only fed into the model)
R.q=q; %another place where q is defined and fed into the model for choices
maxDraws=20;
Ntrials=100;
niter=100;

for iter=1:niter
    for i=1:length(gammaRange)
        gamma=gammaRange(i);
        
        %qH=q+0.025; %generate draw sequences with more certainty than model has below (4.2021):
        qH=0.7;
        drawSequence = generateDrawSequences(qH, maxDraws, Ntrials);
        
        partialUpdate=1.0; %old way of modeling uncertainty
        [reward, choiceTimes,Qsat] = backWardInduction2(Ntrials, maxDraws, drawSequence, R, gamma, partialUpdate);
        
        %avgPercentOfMaxReward(1,i)= (sum(reward)/(R.correct*Ntrials))*100;
        %avgPercentOfMaxReward(1,i)= sum(reward);
        %avgNumDrawsBeforeChoice(1,i)=mean(choiceTimes);
        
        %avgReward(i,iter)=(sum(reward)/(R.correct*Ntrials))*100;
        avgReward(i,iter)=mean(reward); %mean across trials
        avgDraws(i,iter)=mean(choiceTimes);
        stderrReward(i,iter)=stderr(reward);
    end
    
end


%Situation 2: (uncertain environment)
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
clearvars -except avgPercentOfMaxReward avgNumDrawsBeforeChoice gammaRange R q maxDraws Ntrials qH niter...
    avgReward avgDraws

for iter=1:niter
    
    for i=1:length(gammaRange)
        gamma=gammaRange(i);
        
        %qL=q-0.03; %generate draw sequences with less certainty than model has below (4.2021):
        qL=0.54;
        
        drawSequence = generateDrawSequences(qL, maxDraws, Ntrials);
        
        partialUpdate=1.0; %old way of modeling uncertainty
        %partialUpdate=1.0;
        
        [reward, choiceTimes,Qsat] = backWardInduction2(Ntrials, maxDraws, drawSequence, R, gamma, partialUpdate);
        
        %avgPercentOfMaxReward(2,i)= (sum(reward)/(R.correct*Ntrials))*100;
        %avgPercentOfMaxReward(2,i)= sum(reward);
        %avgNumDrawsBeforeChoice(2,i)=mean(choiceTimes);
        
        
        %avgRewardUE(i,iter)=(sum(reward)/(R.correct*Ntrials))*100;
        avgRewardUE(i,iter)=mean(reward);
        avgDrawsUE(i,iter)=mean(choiceTimes);
        stderrRewardUE(i,iter)=stderr(reward);
    end
end

meanAvgRewardIter= [mean(avgReward,2)';mean(avgRewardUE,2)'];
stderrAvgRewardIter= [stderr(avgReward(1,:)), stderr(avgReward(2,:)); stderr(avgRewardUE(1,:)), stderr(avgRewardUE(2,:)) ];

meanAvgDrawsIter= [mean(avgDraws,2)';mean(avgDrawsUE,2)'];
stderrAvgDrawsIter=[stderr(avgDraws(1,:)), stderr(avgDraws(2,:)); stderr(avgDrawsUE(1,:)), stderr(avgDrawsUE(2,:)) ];

[hCert,pCert]=ttest(avgReward(1,:),avgReward(2,:))
[hUE,pUE]=ttest(avgRewardUE(1,:),avgRewardUE(2,:))

figure();
subplot(1,2,1); hold on
%plot reward
bar(meanAvgRewardIter'); set(gcf,'Color',[1 1 1]);set(gca,'fontsize',14)
xe=[0.85,1.85,1.15,2.15];
ye=[meanAvgRewardIter(1,1),meanAvgRewardIter(1,2),meanAvgRewardIter(2,1),meanAvgRewardIter(2,2)];
e=[stderrAvgRewardIter(1,1),stderrAvgRewardIter(1,2),stderrAvgRewardIter(2,1),stderrAvgRewardIter(2,2)];
%errorbar(meanAvgRewardIter',stderrAvgRewardIter','o')
errorbar(xe,ye,e,'k','LineStyle','none')
xticks([1:length(gammaRange)]);
xl=xlabel('Subject Discount Factor'); xl.FontSize = 14;
%xticklabels({'0.55','0.99'})
xticklabels(gammaRange)
yl=ylabel(strcat('Avg Reward', {' '}, num2str(niter),{' '}, 'iter', {' '}, 'iter', {' '}, num2str(Ntrials),{' '}, 'trials'));  yl.FontSize = 14;
legend(char(strcat('High certainty (bead draw seqs)',{' '},num2str(qH))) , char(strcat('Low certainty',{' '},num2str(qL))) );
title(strcat('AvgReward, fraction of beads in majority urn (fed into model)',{' '},num2str(R.q)));

subplot(1,2,2); hold on
%plot avg number of draws before choice
bar(meanAvgDrawsIter'); set(gcf,'Color',[1 1 1])
xticks([1:length(gammaRange)]);
xe=[0.85,1.85,1.15,2.15];
ye=[meanAvgDrawsIter(1,1),meanAvgDrawsIter(1,2),meanAvgDrawsIter(2,1),meanAvgDrawsIter(2,2)];
e=[stderrAvgDrawsIter(1,1),stderrAvgDrawsIter(1,2),stderrAvgDrawsIter(2,1),stderrAvgDrawsIter(2,2)];
errorbar(xe,ye,e,'k','LineStyle','none')
xl=xlabel('Subject Discount Factor'); xl.FontSize = 14;
%xticklabels({'0.55','0.99'})
xticklabels(gammaRange)
yl=ylabel(strcat('Avg num draws before choice', {' '}, num2str(niter),{' '}, 'iter', {' '}, num2str(Ntrials),{' '}, 'trials'));  yl.FontSize = 14;
legend(char(strcat('High certainty (bead draw seqs)',{' '},num2str(qH))) , char(strcat('Low certainty',{' '},num2str(qL))) );
set(gca,'fontsize',14)
title(strcat('Sampling Before Choice, Cost to sample',{' '},num2str(R.sample),{' '},',', ' MaxDraws', ...
    {' '}, num2str(maxDraws),',', {' '},'TotalCost&Rwd:',{' '},num2str(R.error),'|',num2str(R.correct)));
toc

%%  1.25.22 statistical testing: paired sample t-tests

%certain environment:
[h_c, p_c, ci,statsC]= ttest(avgReward(1,:),avgReward(2,:))

%uncertain environment:
[h_uc, p_uc,ci,statsU]= ttest(avgRewardUE(1,:),avgRewardUE(2,:))

%draws:
%uncertain environment:
[hc_draw, pc_draw,ci,statsCC]= ttest(avgDraws(1,:),avgDraws(2,:))

%certain environment:
[h_ucdraw, p_ucdraw, ci,statsCU]= ttest(avgDrawsUE(1,:),avgDrawsUE(2,:))

%% (4b) 11.12.21 plot 2x2 bar plots separately for reward 
figure(2)
subplot(1,2,1); hold on
%plot avg reward for certain environment subplot 1:
bar(meanAvgRewardIter(1,:)); set(gcf,'Color',[1 1 1]);set(gca,'fontsize',14)
xe=[1,2];
ye=meanAvgRewardIter(1,:);
e=[stderrAvgRewardIter(1,:)];
%errorbar(meanAvgRewardIter(1,:),stderrAvgRewardIter(1,:),'o')
errorbar(xe,ye,e,'k','LineStyle','none')
xticks([1:length(gammaRange)]);
xl=xlabel('Subject Discount Factor'); xl.FontSize = 14;
xticklabels(gammaRange)
yl=ylabel(strcat('Avg Reward', {' '}, num2str(niter),{' '}, 'iter', {' '}, 'iter', {' '}, num2str(Ntrials),{' '}, 'trials'));  yl.FontSize = 14;
legend(char(strcat('High certainty (bead draw seqs)',{' '},num2str(qH))));
title(strcat('AvgReward, fraction of beads in majority urn (fed into model)',{' '},num2str(R.q)));

subplot(1,2,2); hold on
%plot avg reward for uncertain environment subplot 2:
bar(meanAvgRewardIter(2,:),'r'); set(gcf,'Color',[1 1 1]);set(gca,'fontsize',14)
xe=[1,2];
ye=meanAvgRewardIter(2,:);
e=[stderrAvgRewardIter(2,:)];
errorbar(xe,ye,e,'k','LineStyle','none')
xticks([1:length(gammaRange)]);
xl=xlabel('Subject Discount Factor'); xl.FontSize = 14;
xticklabels(gammaRange)
yl=ylabel(strcat('Avg Reward', {' '}, num2str(niter),{' '}, 'iter', {' '}, 'iter', {' '}, num2str(Ntrials),{' '}, 'trials'));  yl.FontSize = 14;
legend(char(strcat('Low certainty (bead draw seqs)',{' '},num2str(qL))));
%title(strcat('AvgReward, fraction of beads in majority urn (fed into model)',{' '},num2str(R.q)));


figure(); hold on
%plot avg number of draws before choice
bar(meanAvgDrawsIter'); set(gcf,'Color',[1 1 1])
xticks([1:length(gammaRange)]);
xe=[0.85,1.85,1.15,2.15];
ye=[meanAvgDrawsIter(1,1),meanAvgDrawsIter(1,2),meanAvgDrawsIter(2,1),meanAvgDrawsIter(2,2)];
e=[stderrAvgDrawsIter(1,1),stderrAvgDrawsIter(1,2),stderrAvgDrawsIter(2,1),stderrAvgDrawsIter(2,2)];
errorbar(xe,ye,e,'k','LineStyle','none')
xl=xlabel('Subject Discount Factor'); xl.FontSize = 14;
xticklabels(gammaRange)
yl=ylabel(strcat('Avg num draws before choice', {' '}, num2str(niter),{' '}, 'iter', {' '}, num2str(Ntrials),{' '}, 'trials'));  yl.FontSize = 14;
legend(char(strcat('High certainty (bead draw seqs)',{' '},num2str(qH))) , char(strcat('Low certainty',{' '},num2str(qL))) );
set(gca,'fontsize',14)
title(strcat('Sampling Before Choice, Cost to sample',{' '},num2str(R.sample),{' '},',', ' MaxDraws', ...
    {' '}, num2str(maxDraws),',', {' '},'TotalCost&Rwd:',{' '},num2str(R.error),'|',num2str(R.correct)));


figure(99); 
%plot avg number of draws before choice, 2 bar plots
subplot(1,2,1); 
bar(meanAvgDrawsIter(1,:)); hold on
xe=[1,2];
ye=meanAvgDrawsIter(1,:);
e=[stderrAvgDrawsIter(1,:)];
set(gcf,'Color',[1 1 1]);set(gca,'fontsize',14)
errorbar(xe,ye,e,'k','LineStyle','none')
xticks([1:length(gammaRange)]);
xl=xlabel('Subject Discount Factor'); xl.FontSize = 14;
xticklabels(gammaRange)
yl=ylabel(strcat('Avg num draws before choice', {' '}, num2str(niter),{' '}, 'iter', {' '}, num2str(Ntrials),{' '}, 'trials'));  yl.FontSize = 14;
set(gca,'fontsize',14)
ylim([0 13])

subplot(1,2,2); 
bar(meanAvgDrawsIter(2,:)); hold on
xe=[1,2];
ye=meanAvgDrawsIter(2,:);
e=[stderrAvgDrawsIter(2,:)];
set(gcf,'Color',[1 1 1]);set(gca,'fontsize',14)
errorbar(xe,ye,e,'k','LineStyle','none')
xticks([1:length(gammaRange)]);
xl=xlabel('Subject Discount Factor'); xl.FontSize = 14;
xticklabels(gammaRange)
yl=ylabel(strcat('Avg num draws before choice', {' '}, num2str(niter),{' '}, 'iter', {' '}, num2str(Ntrials),{' '}, 'trials'));  yl.FontSize = 14;
set(gca,'fontsize',14)
title(strcat('Sampling Before Choice, Cost to sample',{' '},num2str(R.sample),{' '},',', ' MaxDraws', ...
    {' '}, num2str(maxDraws),',', {' '},'TotalCost&Rwd:',{' '},num2str(R.error),'|',num2str(R.correct)));
ylim([0 13])


%% Parameter search: determining cost that leads to diminishing returns for an agent with a large d.f.

clear
clearvars
tic

R.correct=10; %reward
R.error= -15; %cost of error

costs=[-0.01]; %costs to sample

q=0.6; %fraction of beads in majority urn
R.q=q; %another place where q is defined
maxDraws=20;
Ntrials=8000;
allGammas= [0.7,0.8,0.85,0.99];

for g=1:length(allGammas)
    
    gamma= allGammas(g);
    
    for i=1:length(costs)
        
        R.sample=costs(i); %cost to sample
        
        drawSequence = generateDrawSequences(q, maxDraws, Ntrials);
        
        partialUpdate=1.0; %no uncertainty around information for draws
        
        %[reward, choiceTimes,Qsat] = backWardInductionDB(Ntrials, maxDraws, drawSequence, R, gamma, partialUpdate);
        [reward, choiceTimes,Qsat] = backWardInduction2(Ntrials, maxDraws, drawSequence, R, gamma, partialUpdate);
        
        avgPercentOfMaxReward(g,i)= (sum(reward)/(R.correct*Ntrials))*100;
        %avgPercentOfMaxReward(g,i)=sum(reward);
        avgNumDrawsBeforeChoice(g,i)=mean(choiceTimes);
    end
end


figure(1);
subplot(1,2,1); hold on
%plot avg reward by cost
plot(-1*costs, avgPercentOfMaxReward,'o-','LineWidth',1.5)
set(gcf,'Color',[1 1 1]);set(gca,'fontsize',14)
xl=xlabel('Cost to sample'); xl.FontSize = 14;
xticks(-1*costs)
yl=ylabel(strcat('Avg % of Max Reward', {' '}, num2str(Ntrials),{' '}, 'trials'));  yl.FontSize = 14;
title(strcat('Avg of Max Reward, fraction of beads in majority urn',{' '},num2str(q)));
legend

subplot(1,2,2); hold on
%plot avg number of draws before choice
plot(-1*costs, avgNumDrawsBeforeChoice,'o-','LineWidth',1.5)
set(gcf,'Color',[1 1 1]);set(gca,'fontsize',14)
xl=xlabel('Cost to sample'); xl.FontSize = 14;
xticks(-1*costs)
yl=ylabel(strcat('Avg num draws before choice', {' '}, num2str(Ntrials),{' '}, 'trials'));  yl.FontSize = 14;
title(strcat('Avg Sampling Before Choice, MaxDraws',{' '},num2str(maxDraws)));
legend


%% (5) Final heatmap parameter demonstration: mismatched urn probabilities, where can we get 0.55 or 0.6 df to do better than 0.99 df? 5.5.21

clear
clearvars
tic

R.correct=10; %reward
R.error= -12; %cost of error
%R.error= -10; %cost of error

maxDraws=20; %could also try varying this
Ntrials=8000;

%allGammas =[0.55, 0.6, 0.65, 0.99]; %discount factor(s) to be tested
allGammas =[0.55, 0.99]; %discount factor(s) to be tested
costs=[-0.0025,-0.005, -0.01, -0.025, -0.05, -0.1, -0.25, -0.5, -1, -1.25, -1.5, -2]; %costs to sample to test

%majUrn_fractions= [0.505, 0.515, 0.525, 0.55, 0.6, 0.65, 0.7, 0.75, 0.8]; %generating bead draws

majUrnTrue=0.55; %fraction in majority urn that is what the model gets

delta_q=[-0.1, -0.075, -0.05, -0.025, -0.01, 0, 0.01, 0.025, 0.05, 0.075, 0.1, 0.2, 0.3, 0.4];


majUrn_fractions= majUrnTrue + delta_q; %generating bead draws

for g= 1:length(allGammas)
    gamma=allGammas(g);

    for F=1:length(majUrn_fractions)
        
        q=majUrn_fractions(F); %fraction of beads in majority urn (use for bead draws)
        
        R.q=majUrnTrue; %another place where q is defined, set this to be what model gets as input
        
        for i=1:length(costs)
            
            R.sample=costs(i); %cost to sample
            
            drawSequence = generateDrawSequences(q, maxDraws, Ntrials);
            
            partialUpdate=1.0; %no uncertainty around information for draws
            
            %[reward, choiceTimes,Qsat] = backWardInductionDB(Ntrials, maxDraws, drawSequence, R, gamma, partialUpdate);
            [reward, choiceTimes,Qsat] = backWardInduction2(Ntrials, maxDraws, drawSequence, R, gamma, partialUpdate);
            
            avgPercentOfMaxReward(F,i)= (sum(reward)/(R.correct*Ntrials))*100;
            %avgPercentOfMaxReward(g,i)=sum(reward);
            avgNumDrawsBeforeChoice(F,i)=mean(choiceTimes);
        end        
    end

    figure(g)
    set(gcf,'Color',[1 1 1])
    subplot(1,2,1);
    surf(costs, delta_q,avgPercentOfMaxReward); hold on
    surf(costs, delta_q,zeros(length(delta_q),length(costs)),'FaceColor','m', 'FaceAlpha',0.5, 'EdgeColor','none');  
    xlabel('cost'); ylabel('delta q'); zlabel('fitness, avg of max reward')
    set(gca,'fontsize',14)
    
    subplot(1,2,2)
    surf(costs, delta_q,avgNumDrawsBeforeChoice)
    %surf(costs, majUrn_fractions,avgNumDrawsBeforeChoice,'FaceColor','b', 'FaceAlpha',0.5, 'EdgeColor','none'); hold on
    xlabel('cost'); ylabel('delta q'); zlabel('avg draws')
    title(strcat('df=',num2str(gamma)));
    set(gca,'fontsize',14)
    
    avgPercentOfMaxReward_AllDFs(g,:,:)=avgPercentOfMaxReward;
    
    avgNumDrawsBeforeChoice_AllDFs(g,:,:)=avgNumDrawsBeforeChoice;
end


%plotting the difference surface (between two discount factors):

avgPercentOfMaxReward_lowDF(:,:)=avgPercentOfMaxReward_AllDFs(3,:,:);
avgPercentOfMaxReward_hiDF(:,:)=avgPercentOfMaxReward_AllDFs(4,:,:);

avgNumDrawsBeforeChoice_lowDF(:,:)=avgNumDrawsBeforeChoice_AllDFs(3,:,:);
avgNumDrawsBeforeChoice_hiDF(:,:)=avgNumDrawsBeforeChoice_AllDFs(4,:,:);

figure(5)
%plot avg fitness, difference between two agents:
set(gcf,'Color',[1 1 1])
subplot(1,2,1);
surf(costs,delta_q,avgPercentOfMaxReward_lowDF-avgPercentOfMaxReward_hiDF);hold on
surf(costs, delta_q,zeros(length(majUrn_fractions),length(costs)),'FaceColor','m', 'FaceAlpha',0.5, 'EdgeColor','none');  hold on
xlabel('cost'); ylabel('delta_q'); zlabel('diff btwn 2 agents (low df- hi df): fitness, avg of max reward')
title(strcat('Mismatch test: fraction of beads in majority urn for draws (varied) vs. model input',{' '},'(',num2str(majUrnTrue)),')')
set(gca,'fontsize',14)
% add to this plot: overlapping surface where
% avgPercentOfMaxReward_lowDF-avgPercentOfMaxReward_hiDF > 0 (impulsive agent better)

%plot of average # of draws, difference between two agents:
subplot(1,2,2)
surf(costs, delta_q,avgNumDrawsBeforeChoice_lowDF-avgNumDrawsBeforeChoice_hiDF); hold on
xlabel('cost'); ylabel('delta_q'); zlabel('diff btwn 2 agents: avg draws')
title(strcat('Differences between results for df=',num2str(allGammas(2)),{' '},'and',{' '},'df=',{' '},num2str(allGammas(3))));
set(gca,'fontsize',14)
toc

%file to save:::
%save('05_13_21_4dfs_evenCost_deltaQ_0.6start.mat')

%% heatmap surface fitting after reloading saved files from this analysis:
% surface fitting after reloading saved files from this analysis:
if 1
    % for custom green/black heatmap:
    tmp=[0:0.01:1];
    map=[zeros(length(tmp),1),tmp',zeros(length(tmp),1)];
    
    for f=1:4
    %for f=1
        %column (different qmodel starting point):
        clearvars -except f i map
        if f==1
            load('05_13_21_4dfs_evenCost_deltaQ_0.55start.mat')
            %load('05_12_21_4dfs_unevenCost_deltaQ_0.55start.mat')
        elseif f==2
            load('05_13_21_4dfs_evenCost_deltaQ_0.575start.mat')
            %load('05_12_21_4dfs_unevenCost_deltaQ_0.575start.mat')
        elseif f==3
            load('05_13_21_4dfs_evenCost_deltaQ_0.6start.mat')
            %load('05_12_21_4dfs_unevenCost_deltaQ_0.6start.mat')
        elseif f==4
            load('05_13_21_4dfs_evenCost_deltaQ_0.65start.mat')
            %load('05_12_21_4dfs_unevenCost_deltaQ_0.65start.mat')
        end
        
        for i=1:3
        %for i=1
            %row (different discount factor for impulsive agent)
            avgPercentOfMaxReward_lowDF(:,:)=avgPercentOfMaxReward_AllDFs(i,:,:); %set to 1 for 0.55 df, 2 for 0.6 df, 3 for 0.65
            avgPercentOfMaxReward_hiDF(:,:)=avgPercentOfMaxReward_AllDFs(4,:,:);
            x=costs; y= delta_q; z=avgPercentOfMaxReward_lowDF-avgPercentOfMaxReward_hiDF;
            figure(2); set(gcf,'Color',[1 1 1]); 
            subplot(3,4,f+ 4*(i-1));
            %f+ 4*(i-1)
            heatmap(x,y,z,'CellLabelColor','none','ColorbarVisible','off'); 
            %heatmap(x,y,z,'CellLabelColor','none')
            %colormap(map); %% SET TO COLORMAP JET OR CUSTOM MAP
            colormap(jet)
            title(strcat('q_{model}=',{''},num2str(majUrnTrue)));
            xlabel('draw cost'); ylabel('q_{beadDraws} - q_{model}');set(gca,'fontsize',14)
            caxis([-50, 20]);
            
        end
    end
end



%% Parameter search: for a low discount factor (0.6 ish) can we get more than 1 draw?

clear
clearvars
tic

R.correct=10; %reward
R.error= -15; %cost of error

maxDraws=15; %could also try varying this
Ntrials=8000;

allGammas =[0.6]; %discount factor(s) to be tested
costs=[-0.01; -0.05; -0.1; -0.15; -0.2; -0.3; -0.4; -0.5; -0.75; -1.0; -2.0]; %costs to sample to test
majUrn_fractions= [0.525, 0.55, 0.6, 0.65, 0.7, 0.75]; %majority urn fractions to test

for g= 1:length(allGammas)
    gamma=allGammas(g);

    for F=1:length(majUrn_fractions)
        q=majUrn_fractions(F); %fraction of beads in majority urn
        R.q=q; %another place where q is defined
        
        for i=1:length(costs)
            
            R.sample=costs(i); %cost to sample
            
            drawSequence = generateDrawSequences(q, maxDraws, Ntrials);
            
            partialUpdate=1.0; %no uncertainty around information for draws
            
            %[reward, choiceTimes,Qsat] = backWardInductionDB(Ntrials, maxDraws, drawSequence, R, gamma, partialUpdate);
            [reward, choiceTimes,Qsat] = backWardInduction2(Ntrials, maxDraws, drawSequence, R, gamma, partialUpdate);
            
            avgPercentOfMaxReward(F,i)= (sum(reward)/(R.correct*Ntrials))*100;
            %avgPercentOfMaxReward(g,i)=sum(reward);
            avgNumDrawsBeforeChoice(F,i)=mean(choiceTimes);
        end        
    end
    avgNumDrawsBeforeChoice
    
    figure(g)
    set(gcf,'Color',[1 1 1])
    subplot(1,2,1);
    surf(costs, majUrn_fractions,avgPercentOfMaxReward);
    %surf(costs, majUrn_fractions,avgPercentOfMaxReward,'FaceColor','b', 'FaceAlpha',0.5, 'EdgeColor','none');  hold on
    xlabel('cost'); ylabel('frac beads in maj urn'); zlabel('fitness, avg of max reward')
    
    subplot(1,2,2)
    surf(costs, majUrn_fractions,avgNumDrawsBeforeChoice)
    %surf(costs, majUrn_fractions,avgNumDrawsBeforeChoice,'FaceColor','b', 'FaceAlpha',0.5, 'EdgeColor','none'); hold on
    xlabel('cost'); ylabel('frac beads in maj urn'); zlabel('avg draws')
    title(strcat('df=',num2str(gamma)));
    
end

%% Parameter effects: how mismatched urn probabilities, d.f. affects reward for fixed (even cost) 4.27.21

clear
clearvars
tic

R.correct=10; %reward
R.error= -12; %cost of error

maxDraws=20; %could also try varying this
Ntrials=8000;

allGammas =[0.55, 0.99]; %discount factor(s) to be tested
costs=[-0.01, -0.025, -0.05, -0.1, -0.25, -0.5, -1]; %costs to sample to test
majUrn_fractions= [0.505, 0.515, 0.525, 0.55, 0.575, 0.6, 0.65, 0.7, 0.8]; %majority urn fractions to test against

majUrnTrues=[0.505, 0.515, 0.525, 0.55, 0.575, 0.6, 0.65, 0.7, 0.8];

for maj=1:length(majUrnTrues)
    majUrnTrue=majUrnTrues(maj);
    
    for g= 1:length(allGammas)
        gamma=allGammas(g);
        
        for F=1:length(majUrn_fractions)
            
            q=majUrn_fractions(F); %fraction of beads in majority urn (use for bead draws)
            
            R.q=majUrnTrue; %another place where q is defined, set this to be what model gets as input
            
            R.sample=costs(1); % fixed cost to sample
            
            drawSequence = generateDrawSequences(q, maxDraws, Ntrials);
            
            partialUpdate=1.0; %no uncertainty around information for draws
            
            [reward, choiceTimes,Qsat] = backWardInduction2(Ntrials, maxDraws, drawSequence, R, gamma, partialUpdate);
            
            avgPercentOfMaxReward(F,g)= (sum(reward)/(R.correct*Ntrials))*100;
            avgNumDrawsBeforeChoice(F,g)=mean(choiceTimes);
            
        end
    end
    figure(maj)
    set(gcf,'Color',[1 1 1])
    subplot(1,2,1);
    surf(allGammas, majUrn_fractions,avgPercentOfMaxReward); hold on
    surf(allGammas, majUrn_fractions,zeros(length(majUrn_fractions),length(allGammas)),'FaceColor','m', 'FaceAlpha',0.5, 'EdgeColor','none');
    xlabel('d.f.'); ylabel('frac beads in maj urn (bead draws)'); zlabel('fitness, avg of max reward')
    set(gca,'fontsize',14)
    
    
    subplot(1,2,2)
    surf(allGammas, majUrn_fractions,avgNumDrawsBeforeChoice)
    %surf(costs, majUrn_fractions,avgNumDrawsBeforeChoice,'FaceColor','b', 'FaceAlpha',0.5, 'EdgeColor','none'); hold on
    xlabel('d.f.'); ylabel('frac beads in maj urn (bead draws)'); zlabel('avg draws')
    title(strcat('True urn fraction (model input):',num2str(majUrnTrue)));
    set(gca,'fontsize',14)
end

toc

%% 9.20.21 Showing effects of df using identical bead sequences


gammaRange=[0.55, 0.99]; 
% R.correct=10; %reward
% R.error= -12; %cost of error
% R.sample= -0.1; %cost to sample
% q=0.55; %fraction of beads in majority urn (usually for making draws & model, but here only fed into the model)
% R.q=q; %another place where q is defined and fed into the model for choices
% maxDraws=20;
% qL=0.54;


R.correct=10; %reward
R.error= -12; %cost of error
R.sample= -0.1; %cost to sample
q=0.55; %fraction of beads in majority urn (usually for making draws & model, but here only fed into the model)
R.q=q; %another place where q is defined and fed into the model for choices
maxDraws=20;
qL=0.7;

gamma1=gammaRange(1);
gamma2=gammaRange(2);

drawSequence = generateDrawSequences(qL, maxDraws, 1);

[reward1, choiceTimes1,Qsat1] = backWardInduction2(1, maxDraws, drawSequence, R, gamma1, 1);
[reward2, choiceTimes2,Qsat2] = backWardInduction2(1, maxDraws, drawSequence, R, gamma2, 1);

Qsat_1(:,:)=Qsat1(1,:,:);
Qsat_2(:,:)=Qsat2(1,:,:);

%3 possible mdp order of actions (pick green, pick blue, draw)


reward1
reward2
%
figure(11);
set(gcf,'Color',[1 1 1])
plot(1:20,Qsat_1(:,1),'go-','LineWidth',1.5); hold on
plot(1:20,Qsat_1(:,2),'bo-','LineWidth',1.5); hold on
plot(1:20,Qsat_1(:,3),'ko--','LineWidth',1.5); hold on
xlabel('Draw')
ylabel('Action Value')
set(gca,'FontSize',14)

%patient agent draw
plot(1:20,Qsat_2(:,3),'ko-','LineWidth',1.5); hold on


legend('Guess Orange', 'Guess Blue','Draw, d.f. 0.55','Draw, d.f. 0.99')

%In case we need to replot the exact sequence used in fig 2C: 
%load('09_20_2021_beadSeqNormal.mat')
% R.correct=10; %reward
% R.error= -10; %cost of error
% R.sample= -0.1; %cost to sample
% q=0.7; %fraction of beads in majority urn (usually for making draws & model, but here only fed into the model)
% R.q=q; %another place where q is defined and fed into the model for choices
% maxDraws=20;

%For figure 2D with uncertainty:
% gammaRange=[0.55, 0.99]; 
% R.correct=10; %reward
% R.error= -12; %cost of error
% R.sample= -0.1; %cost to sample
% q=0.55; %fraction of beads in majority urn (usually for making draws & model, but here only fed into the model)
% R.q=q; %another place where q is defined and fed into the model for choices
% maxDraws=20;
% qL=0.54;
%load('09_20_2021_beadSeqWUncertainty.mat')

%% functions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ll, Qsad, cprob] = fMDPBeads(params, drawData, choiceData)

beta = 0.13;

if ~isempty(params)
    
    maxDraws = 10;
    
    Ntrials = max(size(drawData));
    
    Qsad = NaN*ones(Ntrials, maxDraws, 3);
    
    ll = 0;
    
    for trial = 1 : Ntrials
        
        trialDraws = drawData{trial}(2:end);
        
        nDraws = length(trialDraws);
        
        R.sample = params(1);
        
        if drawData{trial}(1) == 1
            R.correct = 10;
            R.error = -10;
            R.q = 0.8;
        elseif drawData{trial}(1) == 2
            R.correct = 10;
            R.error = -10;
            R.q = 0.6;
        elseif drawData{trial}(1) == 3
            R.correct = 10;
            R.error = 0;
            R.q = 0.8;
        elseif drawData{trial}(1) == 4
            R.correct = 10;
            R.error = 0;
            R.q = 0.6;
        end
        
        for draw = 1 : nDraws
            
            Qsad(trial, draw, 1:3) = backWardUtility(trialDraws, draw, maxDraws, R)';
            
            vVec = Qsad(trial, draw, 1:3);
            
            cprob(trial, draw, :) = exp(beta*vVec)./sum(exp(beta*vVec));
            
        end
        
        seqChoice = (choiceData{trial}(end) == 2) + 1;  %%% 6 green, 2 blue;
        
        if nDraws-1 > 0 & nDraws < maxDraws
            ll = ll - sum(log(squeeze(cprob(trial, nDraws-1, 3)))) - log(squeeze(cprob(trial, nDraws, seqChoice)));
            %             ll = ll - (Qsad(trial, nDraws-1, 3) - max(Qsad(trial, nDraws-1, :))) - ...
            %                       (Qsad(trial, nDraws, seqChoice) - Qsad(trial, nDraws, 3));
        elseif nDraws < maxDraws
            %             ll = ll - (Qsad(trial, nDraws, seqChoice) - Qsad(trial, nDraws, 3));
            ll = ll - log(squeeze(cprob(trial, nDraws, seqChoice)));
        end
        
    end
    
else
    
    Ntrials  = 4;
    maxDraws = 12;
    
    R.correct = 1;
    R.error   = 0;
    R.sample  = -0.025;
    R.q       = 0.6;
    
    drawSequence = generateDrawSequences(R.q, maxDraws, Ntrials);
    
    [r, Qsa] = backWardInduction(Ntrials, maxDraws, drawSequence, R);
    
    figure;
    
    for dri = 1 : 4
        subplot(2,2,dri);
        plot(1:maxDraws, squeeze(Qsa(dri, :, :)), 'LineWidth', 2);
        
        choiceTrial = find(squeeze(Qsa(dri, :, 3)) - max(squeeze(Qsa(dri, :, 1:2))') < 0);
        text(choiceTrial(1), 0.1, 'X', 'horizontalalignment', 'center');
        
        %     legend('Green', 'Blue', 'Draw');
        
        hold on;
        plot(1:maxDraws, drawSequence(dri, :)*0.8 + 0.1, 'ro');
        
        axis([0 maxDraws + 1 0 1]);
        
    end
    
    figure;
    
    R.sample = -0.005;
    
    [r, Qsa] = backWardInduction(Ntrials, maxDraws, drawSequence, R);
    
    for dri = 1 : 4
        subplot(2,2,dri);
        plot(1:maxDraws, squeeze(Qsa(dri, :, :)), 'LineWidth', 2);
        %     legend('Green', 'Blue', 'Draw');
        
        choiceTrial = find(squeeze(Qsa(dri, :, 3)) - max(squeeze(Qsa(dri, :, 1:2))') < 0);
        text(choiceTrial(1), 0.1, 'X', 'horizontalalignment', 'center');
        
        
        hold on;
        plot(1:maxDraws, drawSequence(dri, :)*0.8 + 0.1, 'ro');
        
        axis([0 maxDraws + 1 0 1]);
        
    end
    
end
%fitting actual data
end
%fitting actual data?

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function drawSequence = generateDrawSequences(q, maxDraws, Ntrials)
drawSequence = (rand(Ntrials, maxDraws) < q);
end
% generates a set of trials and draw sequences (0 or 1) based on q and max number of draws
%q= fraction of beads in the majority urn (80/20 or 60/40)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% for running synthetic data (bruno original, not sure the end is
%%% correct... seems to randomize choice)
function [reward, Qsat] = backWardInduction(Ntrials, maxDraws, drawSequence, R, gamma, partialUpdate)

K = 3; %k= # of possible actions (pick green, pick blue, draw)

reward = zeros(Ntrials, 1);

Qsat = zeros(Ntrials, maxDraws, K); %values: choose urn 1/ choose urn 2/ draw

%parfor trial = 1 : Ntrials
for trial = 1 : Ntrials  
    Qsad = zeros(maxDraws, 3);
    
    for draw = 1 : maxDraws      
        Qsad(draw, :) = backWardUtility(drawSequence(trial, :), draw, maxDraws, R,gamma, partialUpdate);    
    end
    
    Qsat(trial, :, :) = Qsad;
    
    Qsad
    
    %%% randomize choice for symmetric values
    Qsac = Qsad + 0.000001*randn(maxDraws, K);
    
    Qsa1 = Qsac(:, 1) - Qsac(:, 3);
    Qsa2 = Qsac(:, 2) - Qsac(:, 3);
    
    choice1 = find(Qsa1 > 0);
    choice2 = find(Qsa2 > 0);
    
    if isempty(choice1)
        choice1(maxDraws+1) = 1;
    end
    
    if isempty(choice2)
        choice2(maxDraws+1) = 1;
    end
    
    if choice1(1) < choice2(1)
        reward(trial) = 1;
    else
        reward(trial) = 0;
    end
    
    
end

end
%calls on backWardUtility
%reward= urn chosen 0 or 1


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [reward, choiceTimes, Qsat] = backWardInductionDB(Ntrials, maxDraws, drawSequence, R, gamma, partialUpdate)

%modified so that :
% reward is trial by trial reward based on number of draws before choice, and whether the final choice was correct or incorrect
% choiceTimes is the numerical draw a choice was made for each trial

K = 3; %k= # of possible actions (pick green, pick blue, draw)

reward = zeros(Ntrials, 1);
choiceTimes =zeros(Ntrials, 1);

Qsat = zeros(Ntrials, maxDraws, K); %values: choose urn 1/ choose urn 2/ draw


for trial = 1 : Ntrials  
    Qsad = zeros(maxDraws, 3);
    
    for draw = 1 : maxDraws      
        Qsad(draw, :) = backWardUtility(drawSequence(trial, :), draw, maxDraws, R, gamma, partialUpdate);    
    end
    
    Qsat(trial, :, :) = Qsad;
    
    
    %take out random part. action values for all possible draws for a single trial: 
    %Qsac = Qsad;
    Qsac = Qsad + 0.000001*randn(maxDraws, K);
    
    
    Qsa1 = Qsac(:, 1) - Qsac(:, 3); %value difference urn 1 vs draw
    Qsa2 = Qsac(:, 2) - Qsac(:, 3); %value difference urn 2 vs draw
    
    choice1 = find(Qsa1 > 0);
    choice2 = find(Qsa2 > 0);
    %we only care about the first value (first draw where action value for
    %a choice exceeds action value of drawing another bead
       
    %get which draw a choice was made and calculate total reward, if a
    %choice was made. otherwise calculate total cost and correct/incorrect
    if isempty(choice1) && isempty(choice2)
        %neither urn was chosen before max draws. choose at random:
        urnChosen=round(rand);
        timeOfChoice=maxDraws;
        %correct or incorrect? (random)
        if urnChosen==1
            %correct
            correct(trial)=1;
        else
            correct(trial)=0;
        end
    elseif isempty(choice1)
        urnChosen=0; %no choice 1s, so choice 2 was chosen 
        timeOfChoice=choice2(1);
        correct(trial)=0;
    elseif isempty(choice2)
        urnChosen=1;
        timeOfChoice=choice1(1);
        correct(trial)=1;
    elseif choice1(1) < choice2(1)
        urnChosen=1; %action value for choice 1 exceeded draw and choice 2 first
        timeOfChoice=choice1(1);
        correct(trial)=1;
    elseif choice1(1) > choice2(1)
        urnChosen=0;
        timeOfChoice=choice2(1);
        correct(trial)=0;
    end  
    
    %calculate total cost for drawing and add reward if correct or incorrect:
    drawingcost=R.sample*timeOfChoice;
    rew=correct(trial)*R.correct + (1-correct(trial))*R.error;
    
    totalReward=rew+drawingcost;
    
    reward(trial)=totalReward;
    choiceTimes(trial)=timeOfChoice;
    
    
end
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Qsa = backWardUtility(drawSequence, draw, maxDraws, R, gamma,partialUpdate)


utility = zeros(maxDraws, maxDraws+1);
ng = sum(drawSequence(1:draw));

for drawi = maxDraws : -1 : (draw + 1)
    [utility] = stateUtilityBeads(utility, drawi, draw, maxDraws, ng, R, gamma,partialUpdate);
end

Qsa = actionValueBeads(utility, R, draw, ng, draw, maxDraws, gamma,partialUpdate);

end
%computes value of state
%calls on stateUtilityBeads and actionValueBeads

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function utility_t = stateUtilityBeads(utility, drawi, draw, maxDraws, ng, R, gamma,partialUpdate)

utility_t = zeros(maxDraws, maxDraws+1);

futureDraws = drawi - draw;

ndf = drawi;

for greenDraws = 0 : futureDraws
    
    ngf = ng + greenDraws;
    
    Qsa = actionValueBeads(utility, R, ndf, ngf, drawi, maxDraws, gamma,partialUpdate);
    
    utility_t(ndf, ngf+1) = max(Qsa);
    
end

end
%computes utility estimate for states except the final state
%calls on actionValueBeads

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Qsa = actionValueBeads(utility, R, nd, ng, drawi, maxDraws, gamma,partialUpdate)

pg = PG(R.q, nd, ng, partialUpdate); %probability we are drawing from the majority urn (it seems blue and green flipped from 2013 paper)

pb = 1 - pg; %probability minority urn

QG = R.correct*pg + R.error*pb; %value of guessing an urn (no discount for these?)
QB = R.correct*pb + R.error*pg;

if drawi < maxDraws
    %updating draw value (original):
    %QD = R.sample + pb*((1-R.q)*utility(nd+1, ng+1+1) +   (R.q)*(utility(nd+1, ng+1))) + ...
    %    pg*(  (R.q)*utility(nd+1, ng+1+1) + (1-R.q)*(utility(nd+1, ng+1)));
    
    %with discounting (set gamma to 1 for no discounting):
        QD = R.sample + gamma* (pb*((1-R.q)*utility(nd+1, ng+1+1) +   (R.q)*(utility(nd+1, ng+1))) + ...
        pg*(  (R.q)*utility(nd+1, ng+1+1) + (1-R.q)*(utility(nd+1, ng+1))));
    
else
    
    QD = 0;
    
end

Qsa = [QG; QB; QD];
%computes action value for drawing again a=draw, QD. 
%calls on PG
end
% where gamma comes in for discounting
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function p= PG(q, nd, ng, partialUpdate)
    %p= 1/(1+ (q/(1-q))^(nd-2*ng)); %original stand alone eqn
     
    %partial evidence update:
    %update nd without fully updating ng
    %ng is total sum of those drawn so far. what if each only gave half evidence?
    %note: this doesn't work right, reward comes out negative
    %ng=partialUpdate*ng; %if partialUpdate=1, same as original
    %p= 1/(1+ (q/(1-q))^(nd-2*ng)); 
    
    %update both bead counts, not just 1 (4.30.21):
    ng=partialUpdate*ng;
    nd=partialUpdate*nd;  
    p= 1/(1+ (q/(1-q))^(nd-2*ng)); 

end
%probability we are drawing from the majority urn. (p=pblue in 2013 paper, here green)
%q= fraction of beads in the majority urn (80/20 or 60/40)
%ng=number drawn of target color (blue in 2013 paper, green here)
%nd=total number of draws








