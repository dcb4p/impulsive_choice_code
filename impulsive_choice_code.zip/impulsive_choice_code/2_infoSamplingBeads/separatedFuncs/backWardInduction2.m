function [reward, choiceTimes, Qsat] = backWardInduction2(Ntrials, maxDraws, drawSequence, R, gamma, partialUpdate)

%2nd attempt at modifying to get choiceTime and total reward 4.7.21

K = 3; %k= # of possible actions (pick green, pick blue, draw)

reward = zeros(Ntrials, 1);

Qsat = zeros(Ntrials, maxDraws, K); %values: choose urn 1/ choose urn 2/ draw

%parfor trial = 1 : Ntrials
for trial = 1 : Ntrials  
    Qsad = zeros(maxDraws, 3);
    
    for draw = 1 : maxDraws      
        Qsad(draw, :) = backWardUtility(drawSequence(trial, :), draw, maxDraws, R,gamma, partialUpdate);    
    end
    
    Qsat(trial, :, :) = Qsad;
    
    %Qsad
    
    %%% randomize choice for symmetric values
    Qsac = Qsad + 0.000001*randn(maxDraws, K);
    
    Qsa1 = Qsac(:, 1) - Qsac(:, 3);
    Qsa2 = Qsac(:, 2) - Qsac(:, 3);
    
    choice1 = find(Qsa1 > 0);
    choice2 = find(Qsa2 > 0);
    
    if isempty(choice1)
        %choice1(maxDraws+1) = 1;%original, this makes this choice pickedtho
        choice1(1) = maxDraws+1;
    end
    
    if isempty(choice2)
        %choice2(maxDraws+1) = 1; %original, this makes this choice pickedtho
        choice2(1) = maxDraws+1;
    end
    
    if choice1(1) < choice2(1)
        %reward(trial) = 1;
        reward(trial) = R.correct + R.sample*choice1(1);
        choiceTimes(trial)= choice1(1);
    else
        %reward(trial) = 0;
        reward(trial) = R.error + R.sample*choice2(1);
        choiceTimes(trial)= choice2(1);
    end
    
    
end

end
%calls on backWardUtility
%reward= urn chosen 0 or 1