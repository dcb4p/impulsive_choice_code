function p= PG(q, nd, ng, partialUpdate)
    %p= 1/(1+ (q/(1-q))^(nd-2*ng)); %original stand alone eqn
     
    %partial evidence update:
    %update nd without fully updating ng
    %ng is total sum of those drawn so far. what if each only gave half evidence?
    %note: this doesn't work right, reward comes out negative
    ng=partialUpdate*ng; %if partialUpdate=1, same as original
    p= 1/(1+ (q/(1-q))^(nd-2*ng)); 

end