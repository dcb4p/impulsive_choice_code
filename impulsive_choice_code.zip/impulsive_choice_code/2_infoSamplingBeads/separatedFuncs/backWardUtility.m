function Qsa = backWardUtility(drawSequence, draw, maxDraws, R, gamma,partialUpdate)


utility = zeros(maxDraws, maxDraws+1);
ng = sum(drawSequence(1:draw));

for drawi = maxDraws : -1 : (draw + 1)
    [utility] = stateUtilityBeads(utility, drawi, draw, maxDraws, ng, R, gamma,partialUpdate);
end

Qsa = actionValueBeads(utility, R, draw, ng, draw, maxDraws, gamma,partialUpdate);

end
%computes value of state
%calls on stateUtilityBeads and actionValueBeads