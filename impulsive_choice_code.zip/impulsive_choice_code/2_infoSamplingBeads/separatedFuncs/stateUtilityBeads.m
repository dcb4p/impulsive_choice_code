function utility_t = stateUtilityBeads(utility, drawi, draw, maxDraws, ng, R, gamma,partialUpdate)

utility_t = zeros(maxDraws, maxDraws+1);

futureDraws = drawi - draw;

ndf = drawi;

for greenDraws = 0 : futureDraws
    
    ngf = ng + greenDraws;
    
    Qsa = actionValueBeads(utility, R, ndf, ngf, drawi, maxDraws, gamma,partialUpdate);
    
    utility_t(ndf, ngf+1) = max(Qsa);
    
end

end
%computes utility estimate for states except the final state
%calls on actionValueBeads