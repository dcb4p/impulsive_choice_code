function Qsa = actionValueBeads(utility, R, nd, ng, drawi, maxDraws, gamma,partialUpdate)

pg = PG(R.q, nd, ng, partialUpdate); %probability we are drawing from the majority urn (it seems blue and green flipped from 2013 paper)

pb = 1 - pg; %probability minority urn

QG = R.correct*pg + R.error*pb; %value of guessing an urn (no discount for these?)
QB = R.correct*pb + R.error*pg;

if drawi < maxDraws
    %updating draw value (original):
    %QD = R.sample + pb*((1-R.q)*utility(nd+1, ng+1+1) +   (R.q)*(utility(nd+1, ng+1))) + ...
    %    pg*(  (R.q)*utility(nd+1, ng+1+1) + (1-R.q)*(utility(nd+1, ng+1)));
    
    %with discounting (set gamma to 1 for no discounting):
        QD = R.sample + gamma* (pb*((1-R.q)*utility(nd+1, ng+1+1) +   (R.q)*(utility(nd+1, ng+1))) + ...
        pg*(  (R.q)*utility(nd+1, ng+1+1) + (1-R.q)*(utility(nd+1, ng+1))));
    
else
    
    QD = 0;
    
end

Qsa = [QG; QB; QD];
%computes action value for drawing again a=draw, QD. 
%calls on PG
end
% where gamma comes in for discounting