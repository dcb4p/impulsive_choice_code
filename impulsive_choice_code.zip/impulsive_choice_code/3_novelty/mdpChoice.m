
%1. mdpChoice
%2. testBackWardInduction
%3. backWardInduction
%4. truncatedBackWardUtility
%5. runDebug
%6. stateUtility2
%7. stateUtility3
%8. stateUtilityNovel
%9. actionValue2
%10. actionValueNovel
%11. utilityState2
%12. utilityState3
%13. utilityStateNovel

function [Qsa, Qtran] = mdpChoice(Ntrials)

if isempty(Ntrials)
    %%% number of trials
    N = 40;
else
    N = Ntrials;
end

[Qsa, Qtran] = testBackWardInduction(N);
    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% setup test data and run several random versions to see if value
%%% estimates make sense
function [Qsa, Qtran] = testBackWardInduction(Ntrials)

%%% number of choices
K = 2;

N = Ntrials;

%%% reward probabilities for choices
rp(1) = 0.75;
rp(2) = 1 - rp(1);
rp(3) = 0.5;

lambda = 1;

[rewards, choices, Qsa, Qtran] = backWardInduction(K, N, rp, lambda);
    

if Ntrials < 20
    nPlot = Ntrials;
else
    nPlot = 20;
end

if K == 2
        
    Qd  = Qsa(:, 1) - Qsa(:, 2);
%     Qd  = (Qd - min(Qd))/(max(Qd) - min(Qd));    
%     Qdg = 0.5 - Qd(1);    
%     Qd  = Qd + Qdg;
    
%     figure;    
%     plot(1:nPlot, Qd(1, 1:nPlot), ...
%         1:nPlot, reward_t(1, 1:nPlot)*0.6 + 0.2, '+',...
%         1:nPlot, (choices_t(1, 1:nPlot)-1)*0.5+0.25, 'x', 1:nPlot, 0.5*ones(nPlot, 1), '-');
%     axis([0 nPlot+1 0 1]);
%     
    Qdtran = Qtran(:, 1) - Qtran(:, 2);
%     plot(1:nPlot, Qdtran(1:nPlot));
    
    figure;
    subplot(2,2,1);
    plot(1:nPlot, Qd(1:nPlot), ...
         1:nPlot, Qdtran(1:nPlot), ...
         1:nPlot, rewards(1:nPlot)*0.6 + 0.2 - 0.5, '+',...
         1:nPlot, (choices(1:nPlot)-1)*0.5+0.25 - 0.5, 'x', ...
         1:nPlot, zeros(nPlot, 1), 'LineWidth', 2);
    axis([0 nPlot+1 -0.4 0.4]);
    title(N);
    
        
elseif K == 3
    
%     Qa(:, 1) = Qsat(1, 1:N)';
%     Qa(:, 2) = Qsat(1, N+1:2*N)';
%     Qa(:, 3) = Qsat(1, 2*N+1:end)';
%     
%     Qt(:, 1) = Qtran(1, 1:N)';
%     Qt(:, 2) = Qtran(1, N+1:2*N)';
%     Qt(:, 3) = Qtran(1, 2*N+1:end)';
%     
%     figure;  
%     subplot(2, 1, 1);
%     Nf = 6;
%     plot(1:nPlot, Qa(1:nPlot, 1)./(Nf)', 1:nPlot, Qa(1:nPlot, 2)./(Nf)', ...
%     1:nPlot, Qa(1:nPlot, 3)./(Nf)', ...
%         1:nPlot, reward_t(1, 1:nPlot)*0.6 + 0.2, '+',...
%         1:nPlot, (choices_t(1, 1:nPlot)-1)*0.4+0.1, 'x');
%     axis([0 nPlot+1 0 1]);
% 
% 
%     subplot(2,1,2);
%     plot(1:nPlot, Qt(1:nPlot, 1)./(Nf)', 1:nPlot, Qt(1:nPlot, 2)./(Nf)', ...
%     1:nPlot, Qt(1:nPlot, 3)./(Nf)');
% 
%     axis([0 nPlot+1 0 1]);
    
end

figure;
if K == 2
    subplot(2,2,1);
    plot(1:N, Qsa(:, 1), 1:N, Qsa(:, 2));
    
    subplot(2,2,2);
    plot(1:N, Qsa(:,1)./((N:-1:1))', 1:N, Qsa(:,2)./((N:-1:1))');
    
    subplot(2,2,4);
    plot(1:N, Qtran(:,1), 1:N, Qtran(:,2), ...
         1:N, Qsa(:,1) - Qtran(:,1), 1:N, Qsa(:,2) - Qtran(:,2));    
     
    hold on;
    plot(1:N, rewards*2, '*', 1:N, choices-1 + 0.1, 'x'); 
    
else
    subplot(2,2,1);
    plot(1:N, Qsa(:,1), 1:N, Qsa(:,2), 1:N, Qsa(:,3));
    
    subplot(2,2,2);
    plot(1:N, Qtran(:,1), 1:N, Qtran(:,2), 1:N, Qtran(:,3));
    
    subplot(2,2,3);
    plot(1:N, rewards*2, '*', 1:N, choices-1 + 0.1, 'x');    
    axis([0 Inf -0.2 2.2]);
    
    subplot(2,2,4);
    plot(1:N, Qtran(:,1), 1:N, Qtran(:,2), 1:N, Qtran(:,2), ...
         1:N, Qsa(:,1) - Qtran(:,1), 1:N, Qsa(:,2) - Qtran(:,2), 1:N, Qsa(:,3) - Qtran(:,3));    
     
    hold on;
    plot(1:N, rewards*2, '*', 1:N, choices-1 + 0.1, 'x');    
    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% for running synthetic daata
function [rewards, choices, Qsat, Qtrant] = backWardInduction(K, N, rp, lambda)

%%% max states into the future

if K == 2
    maxState = N;
else
    maxState = 6;
end

priorProb(1) = 2;
priorProb(2) = 4;

%%% setup synethic rewards for a sample run
for choices = 1 : K
    R(:, choices) = (rand(N, 1) < rp(choices));
end

% R(1, 1) = 1;
% R(2, 1) = 1;
% R(3, 1) = 1;
% R(4, 1) = 0;
% R(5, 1) = 0;
% R(6, 1) = 0;
% R(7, 2) = 1;
% R(8, 2) = 1;
% R(9, 2) = 1;
% R(10, 2) = 0;
% R(11, 2) = 0;
% R(12, 2) = 0;
% R(13, 3) = 0;
% R(14, 1) = 0;
% R(15, 2) = 1;
% 
% choiceVec = [1 1 1 1 1 1 2 2 2 2 2 2 2 1 2];

R(1, 1) = 1;
R(2, 1) = 1;
R(3, 1) = 1;
R(4, 1) = 1;
R(5, 1) = 1;
R(6, 1) = 1;
R(7, 1) = 1;
R(8, 1) = 1;
R(9, 1) = 1;
R(10, 1) = 1;
R(11, 1) = 1;
R(12, 1) = 1;
R(13, 1) = 1;
R(14, 1) = 1;
R(15, 1) = 1;

choiceVec = [1 1 1 1 1 1 1 1 1 1 1 1 1 1 1];

%%% tracks choices and rewards
S = zeros(K, 2);

%%% actual rewards
rewards = zeros(N, 1);

%%% 1 if a novel option is introduced, 0 if not for each stim/trial
novelOption = zeros(N, K);

%%% if negative 1 then no novel stimuli
if K == 2 || K == 3
    novelTrial = -1;
else
    novelTrial = 1;
end

%%% hand coded introductions of novel stimuli
if K > 1 && novelTrial > -1

    novelOption(15, 1) = 1;
    novelOption(20, 2) = 1;
    novelOption(30, 1) = 1;
    
end

Qsat   = zeros(N, K);
Qtrant = zeros(N, K);

for t = 1 : N
    
    fprintf('Trial %d\n', t);
        
    z = find(novelOption(t, :) == 1);
    
    if sum(z) > 0
        S(z, 1:2) = 0;
        
        if z == 1 & t == 13
            R(:, z) = (rand(N, 1) < rp(2));  
        elseif z == 1 & t == 30
            R(:, z) = (rand(N, 1) < rp(1));  
            R(:, 2) = (rand(N, 1) < rp(2));  
        elseif z == 2
            R(:,z) = (rand(N, 1) < rp(1));     
        elseif z == 3
            R(:,z) = (rand(N, 1) < rp(1));   
        end
        
        novelTrial = t;
    end
           
    [Qsa, Qtran] = truncatedBackWardUtility(S, N, t, lambda, novelTrial, maxState, priorProb);
                
    %%% randomize choice for symmetric values
    Qsac = Qsa + 0.000001*randn(K, 1);

    [vi, choicei] = max(Qsac);
    
    if t == 1
        choicei = 1;
    end
    
    if t < length(choiceVec)
        choicei = choiceVec(t);
    end
    
    Qsat(t, :) = Qsa;
    Qtrant(t, :) = Qtran;
    
    rewards(t) = R(t, choicei);
    
    S(choicei, 1) = S(choicei, 1) + R(t, choicei);
    S(choicei, 2) = S(choicei, 2) + 1;
    
    choices(t) = choicei;    
            
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Qsa, Qtran] = truncatedBackWardUtility(S, N, t, lambda, novelTrial, maxState, priorProb)

K = size(S, 1);

if N > maxState && K > 2
    
    Ne = t + maxState - 1;
    
    if novelTrial > -1 Nstates = (2*(maxState+1))^(2*K);
    else               Nstates = (maxState+1)^(2*K);
    end
    
    if Ne > N  Ne = N;
    end
    
    truncated = 1;
    
else
    Ne = N;
    Nstates = (N+1)^(2*K);
    truncated = 0;
    maxState = N;
end

utility = zeros(Nstates, 1);

P = sparse(Nstates, Nstates);
P1 = sparse(Nstates, Nstates);
P2 = sparse(Nstates, Nstates);
P3 = sparse(Nstates, Nstates);
rf = sparse(Nstates, 1);

for ti = (Ne-1) : -1 : t
    
    if novelTrial > 0 dnovelTrial = ti - novelTrial;
    else              dnovelTrial = -1;
    end
        
    if K == 2
        [utility] = stateUtility2(utility, Nstates, S, ti, N, lambda, priorProb);
    elseif K == 3 & novelTrial == -1
        [utility] = stateUtility3(utility, Nstates, S, t, ti, maxState, Ne, lambda, dnovelTrial, truncated, priorProb, P, P1, P2, P3, rf);
    else
        [utility, P, P1, P2, P3, rf] = stateUtilityNovel(utility, Nstates, S, t, ti, maxState, Ne, lambda, dnovelTrial, truncated,...
            0, [1 3], priorProb, P, P1, P2, P3, rf);
    end 
    
end
    
if K == 2
    
    [Qsa, Qtran] = actionValue2(S(1,2), S(2,2), S(1,1), S(2,1), N, Ne-t, utility, lambda, priorProb);
    
elseif K == 3
    
    if novelTrial > 0
        dnovelTrial = t - novelTrial;        
    else
        dnovelTrial = -1;        
    end
    
    if novelTrial == -1
    
        si = utilityState3(S(1,2), S(2,2), S(3,2), S(1,1), S(2,1), S(3,1), maxState, truncated, S);
        
    else
        
        si = utilityStateNovel(S(1,2), S(2,2), S(3,2), S(1,1), S(2,1), S(3,1), maxState, S);
        
    end
    
    [Qsa, Qtran] = actionValueNovel(S(1,2), S(2,2), S(3,2), S(1,1), S(2,1), S(3,1), ...
        maxState, Ne-t, utility, lambda, dnovelTrial, truncated, S, priorProb, si, P, P1, P2, P3, rf);
    
%     runDebug(Qsa, S, t, maxState, Ne, lambda, novelTrial, truncated, Nstates, priorProb);

end    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function runDebug(Qsa, S, t, maxState, Ne, lambda, novelTrial, truncated, Nstates, priorProb)
   
choices = [];

epsilon = 0.00001;

if norm(S(1,:) - S(2,:)) == 0 & abs(Qsa(1) - Qsa(2)) > epsilon
    choices = [1 2];
end

if norm(S(2,:) - S(3,:)) == 0 & abs(Qsa(2) - Qsa(3)) > epsilon
    choices = [2 3];
end

if norm(S(1,:) - S(3,:)) == 0 & abs(Qsa(1) - Qsa(3)) > epsilon
    choices = [1 3];
end

if isempty(choices) 
    return;
end

fprintf('Action values do not match %d %d %d %d %d %d %.4f %.4f\n', t, novelTrial, S(choices(1), 1), S(choices(1), 2), ...
    S(choices(2), 1), S(choices(2), 2), Qsa(choices(1)), Qsa(choices(2)));

Qsa
S
    
utility = zeros(Nstates, 1);

sv = 1;
for ti = Ne : -1 : t + 1
    
    if novelTrial > 0 dnovelTrial = ti - novelTrial;
    else              dnovelTrial = -1;
    end
    
    if ti == t + 1
        fprintf('');        
    end
    
    [utility] = stateUtilityNovel(utility, Nstates, S, t, ti, maxState, Ne, lambda, dnovelTrial, truncated, sv, choices, priorProb); 
  
end

dnovelTrial = t - novelTrial;        
Qsa = actionValueNovel(S(1,2), S(2,2), S(3,2), S(1,1), S(2,1), S(3,1), maxState, Ne-t, utility, lambda, dnovelTrial, truncated, S, priorProb);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [utility_t] = stateUtility2(utility, Nstates, S, ti, N, lambda, priorProb)

c1i = S(1,2);
c2i = S(2,2);

r1i = S(1,1);
r2i = S(2,1);

utility_t = zeros(Nstates, 1);

for c1 = c1i : ti
    
    for c2 = c2i : ti
        
        if c1 + c2 == ti
            
            for r1 = r1i : c1 - (c1i - r1i)
                
                for r2 = r2i : c2 - (c2i - r2i)
                                        
                    si = utilityState2(c1, c2, r1, r2, N);
                    
                    [u, ~] = actionValue2(c1, c2, r1, r2, N, N-ti, utility, lambda, priorProb);
                                                                
                    [utility_t(si), chi] = max(u);      
                    
%                     fprintf('1 %d %d 2 %d %d %.2f %.2f %d;\n', r1, c1, r2, c2, u(1), u(2), chi);
                                        
                end
            end
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [utility_t] = stateUtility3(utility, Nstates, S, t, ti, maxState, Ne, lambda, dnovelTrial, truncated, priorProb, P, P1, P2, P3, rf)

c1i = S(1,2);
c2i = S(2,2);
c3i = S(3,2);

r1i = S(1,1);
r2i = S(2,1);
r3i = S(3,1);

samples = ti - t + 1;

totalSamples = sum(S(:,2)) + samples;

c1Outcomes = (c1i : c1i + samples);
c2Outcomes = (c2i : c2i + samples);
c3Outcomes = (c3i : c3i + samples);

utility_t = zeros(Nstates, 1);

for c1 = c1Outcomes
    
    for c2 = c2Outcomes
        
        for c3 = c3Outcomes
        
            if c1 + c2 + c3 == totalSamples

                for r1 = r1i : c1

                    for r2 = r2i : c2

                        for r3 = r3i : c3
                                        
                            si = utilityState3(c1, c2, c3, r1, r2, r3, maxState, truncated, S);
                                                        
                            [u, ~] = actionValueNovel(c1, c2, c3, r1, r2, r3, ...
                            maxState, Ne-ti, utility, lambda, dnovelTrial, truncated, S, priorProb, si, P, P1, P2, P3, rf);
                            
                            utility_t(si) = max(u);                
                                        
                        end
                    end
                end
            end
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [utility_t, P, P1, P2, P3, rf] = stateUtilityNovel(utility, Nstates, ...
    S, t, ti, maxState, Ne, lambda, dnovelTrial, truncated, pltv, svch, priorProb, P, P1, P2, P3, rf)

c1i = S(1,2);
c2i = S(2,2);
c3i = S(3,2);

r1i = S(1,1);
r2i = S(2,1);
r3i = S(3,1);

samples = ti - t + 1;

c1Outcomes = union((0 : samples), (c1i : c1i + samples));
c2Outcomes = union((0 : samples), (c2i : c2i + samples));
c3Outcomes = union((0 : samples), (c3i : c3i + samples));

r1Outcomes = union((0 : samples), (r1i : r1i + samples));
r2Outcomes = union((0 : samples), (r2i : r2i + samples));
r3Outcomes = union((0 : samples), (r3i : r3i + samples));

mn = [];

%%% debug code
if pltv == 1
    
    mxv(1) = max(c1Outcomes)+1;
    mxv(2) = max(c2Outcomes)+1;
    mxv(3) = max(c3Outcomes)+1;    
    
    mn = zeros(mxv(1), mxv(2), mxv(3), mxv(1), mxv(2), mxv(3), 2);
    
end

utility_t = zeros(Nstates, 1);

for c1 = c1Outcomes
    
    fprintf('C1 %d max %d\n', c1, max(c1Outcomes));
    
    for c2 = c2Outcomes
        
        for c3 = c3Outcomes
                                                
            for r1 = r1Outcomes
                
                if r1 > c1
                    continue;
                end

                for r2 = r2Outcomes
                    
                    if r2 > c2 
                        continue;
                    end

                    for r3 = r3Outcomes
                        
                        if r3 > c3
                            continue;
                        end

                        si = utilityStateNovel(c1, c2, c3, r1, r2, r3, maxState, S);
                        
                        [Qsa, ~, P, P1, P2, P3, rf] = actionValueNovel(c1, c2, c3, r1, r2, r3, maxState, Ne-ti, utility, lambda, dnovelTrial, truncated, S, priorProb, si, P, P1, P2, P3, rf);
                        
                        if min(Qsa) < 0
                            fprintf('');
                        end
                        
%                         if pltv == 1
%                             mn(c1+1, c2+1, c3+1, r1+1, r2+1, r3+1, 1:2) = Qsa(svch);                            
%                         end

                        utility_t(si) = max(Qsa);                
                        
                    end
                end
            end
        end
    end
end

fprintf('');

if pltv == 1
    
    for svi1 = c1Outcomes
        for svi2 = c2Outcomes
            for svi3 = c3Outcomes
                for rvi1 = 0 : r1Outcomes
                    if rvi1 > svi1 
                        continue;
                    end
                    for rvi2 = r2Outcomes
                        if rvi2 > svi2
                            continue;
                        end
                        for rvi3 = r3Outcomes
                            if rvi3 > svi3
                                continue;
                            end
                            if svch(1) == 2 & svch(2) == 3
                                if mn(svi1+1, svi2+1, svi3+1, rvi1+1, rvi2+1, rvi3+1, 1) ~= ... 
                                   mn(svi1+1, svi3+1, svi2+1, rvi1+1, rvi3+1, rvi2+1, 2)
                                    fprintf('');

                                    Qsa = actionValueNovel(svi1, svi2, svi3, rvi1, rvi2, rvi3, maxState, Ne-ti, utility, lambda, dnovelTrial, truncated, S, priorProb);

                                    Qsa

                                    Qsa = actionValueNovel(svi1, svi3, svi2, rvi1, rvi3, rvi2, maxState, Ne-ti, utility, lambda, dnovelTrial, truncated, S, priorProb);

                                    Qsa

                                end
                            end
                            
                            if svch(1) == 1 & svch(2) == 3
                                
                                if mn(svi1+1, svi2+1, svi3+1, rvi1+1, rvi2+1, rvi3+1, 1) ~= ... 
                                   mn(svi3+1, svi2+1, svi1+1, rvi3+1, rvi2+1, rvi1+1, 2)
                                    fprintf('');
                                    Qsa = actionValueNovel(svi1, svi2, svi3, rvi1, rvi2, rvi3, maxState, Ne-ti, utility, lambda, dnovelTrial, truncated, S, priorProb);

                                    Qsa

                                    Qsa = actionValueNovel(svi3, svi2, svi1, rvi3, rvi2, rvi1, maxState, Ne-ti, utility, lambda, dnovelTrial, truncated, S, priorProb);

                                    Qsa                            

                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Qsa, Qtran] = actionValue2(c1, c2, r1, r2, N, endstate, utility, lambda, priorProb)

p1 = (r1+priorProb(1))/(c1+priorProb(2));
p2 = (r2+priorProb(1))/(c2+priorProb(2));

if endstate == 0
    
    Qsa(1, 1) = p1;
    Qsa(2, 1) = p2;
    
    Qtran(1, 1) = 0;
    Qtran(2, 1) = 0;
        
else

    %%% choose 1 no reward
    s11 = utilityState2(c1+1, c2, r1, r2, N);

    u11 = (1-p1)*utility(s11);

    %%% choose 1 reward
    s12 = utilityState2(c1+1, c2, r1+1, r2, N);

    u12 = p1*utility(s12);

    %%% choose 2 no reward
    s21 = utilityState2(c1, c2+1, r1, r2, N);

    u21 = (1-p2)*utility(s21);

    %%% choose 2 reward
    s22 = utilityState2(c1, c2+1, r1, r2+1, N);

    u22 = p2*utility(s22);
    
    if (u11 == 0 | u12 == 0 | u21 == 0 | u22 == 0) & endstate > 1
        fprintf('zero utility in action value 2\n');
    end

    Qsa(1, 1) = p1 + lambda*(u11 + u12);
    Qsa(2, 1) = p2 + lambda*(u21 + u22);
    
    Qtran(1, 1) = lambda*(u11 + u12);
    Qtran(2, 1) = lambda*(u21 + u22);
    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Qsa, Qtran, P, P1, P2, P3, rf] = actionValueNovel(c1, c2, c3, r1, r2, r3, maxState, ...
    endState, utility, lambda, dnovelTrial, truncated, S, priorProb, si, P, P1, P2, P3, rf)

rp(1) = (r1+priorProb(1))/(c1+priorProb(2));
rp(2) = (r2+priorProb(1))/(c2+priorProb(2));
rp(3) = (r3+priorProb(1))/(c3+priorProb(2));

if endState == 0
    
    u = zeros(3, 4);    
    pmat = [];
    
else
    
    if dnovelTrial > -1
        
        pswitch = 0.05;

    else
        pswitch = 0;
    end
    
    for choice = 1 : 3
        
        choiceOutcome = 1;
        nrm = 0;
        chprb = zeros(8, 1);
        chuti = zeros(8, 1);
        
        for rew = 0 : 1
            for swtch = 0 : 1
                for subch = 1 : 3
                    
                    if swtch == 0 & subch > 1
                        continue;
                    end
                    
                    if swtch == 1 & dnovelTrial == -1
                        continue;
                    end
                    
                    fc1 = (c1 + (choice == 1))*(~((swtch==1)&(subch == 1)));
                    fc2 = (c2 + (choice == 2))*(~((swtch==1)&(subch == 2)));
                    fc3 = (c3 + (choice == 3))*(~((swtch==1)&(subch == 3)));
                    
                    fr1 = (r1 + (choice == 1)*rew)*(~((swtch==1)&(subch == 1)));
                    fr2 = (r2 + (choice == 2)*rew)*(~((swtch==1)&(subch == 2)));
                    fr3 = (r3 + (choice == 3)*rew)*(~((swtch==1)&(subch == 3)));                    
                
                    S0 = S;
                    if swtch == 1
                        S0(subch,1) = 0;
                        S0(subch,2) = 0;
                    end
                    
                    if dnovelTrial == -1
                        sij = utilityState3(fc1, fc2, fc3, fr1, fr2, fr3, maxState, truncated, S0);
                    else
                        sij = utilityStateNovel(fc1, fc2, fc3, fr1, fr2, fr3, maxState, S0);
                    end
                    
                    prb = (rew*rp(choice) + (1-rew)*(1-rp(choice)))* ...
                          (swtch*pswitch  + (1-swtch)*(1-pswitch))* ...
                          (swtch*(1/3)    + (1-swtch));
                      
                    pmat(choice, choiceOutcome, 1) = prb;
                    pmat(choice, choiceOutcome, 2) = sij;
                    
                    if choice == 1
                        P1(si, sij) = prb;
                    elseif choice == 2
                        P2(si, sij) = prb;
                    else
                        P3(si, sij) = prb;
                    end
                      
                    try
                        u(choice, choiceOutcome) = prb*utility(sij);
                        
                        if utility(sij) == 0 & endState > 1
                            fprintf('%d %d %d %d %d %d\n', fc1, fc2, fc3, fr1, fr2, fr3);
                        end
                        
                    catch
                        fprintf('');
                    end
                                        
                    
                    nrm = nrm + prb;
                                        
                    choiceOutcome = choiceOutcome + 1;
                    
                end
            end
        end
                
        if abs(nrm - 1) > 0.01
            fprintf('bad norm');
        end
                
    end
end

Qsa = rp' + lambda*sum(u, 2);

Qtran = lambda*sum(u, 2);

[~, qi] = max(Qsa);

rf(si) = rp(qi);

if si == 12305 | (endState == 1 && sum(find(pmat(qi, :, 2) == 12305)) > 0)
    fprintf('');
end

   
if endState == 1
    
    P(squeeze(pmat(qi, :, 2)), 1) = 1;
    P1(squeeze(pmat(qi, :, 2)), 1) = 1;
    P2(squeeze(pmat(qi, :, 2)), 1) = 1;
    P3(squeeze(pmat(qi, :, 2)), 1) = 1;
    
else
    
    if endState == 1 && sum(pmat(qi, :, 1)) - 1 > 0.01
        fprintf('');
    end
    
    if sum(P(si, :)) > 0
        P(si, :) = 0;
    end

    for indi = 1 : size(pmat, 2)
        P(si, squeeze(pmat(qi, indi, 2))) = P(si, squeeze(pmat(qi, indi, 2))) + squeeze(pmat(qi, indi, 1));
    end
    
    if abs(sum(P(si, :)) - 1) > 0.1
        fprintf('');
    end
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function s = utilityState2(c1, c2, r1, r2, N)

N1 = N + 1;

s = 1 + r2 + r1*N1 + c2*N1^2 + c1*N1^3;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function si = utilityState3(c1, c2, c3, r1, r2, r3, maxState, truncated, S)

if truncated == 1
    
    c1 = c1 - S(1,2);
    c2 = c2 - S(2,2);
    c3 = c3 - S(3,2);
    
    r1 = r1 - S(1,1);
    r2 = r2 - S(2,1);
    r3 = r3 - S(3,1);
    
end 

N1 = maxState + 1;

si = 1 + r3 + r2*N1 + r1*N1^2 + c3*N1^3 + c2*N1^4 + c1*N1^5;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function si = utilityStateNovel(c1, c2, c3, r1, r2, r3, maxState, S)

N1 = 2*(maxState + 1);

if c1 > maxState 
    c1 = c1 - S(1,2) + maxState;
end

if c2 > maxState
    c2 = c2 - S(2,2) + maxState;
end

if c3 > maxState
    c3 = c3 - S(3,2) + maxState;
end

if r1 > maxState
    r1 = r1 - S(1,1) + maxState;
end

if r2 > maxState
    r2 = r2 - S(2,1) + maxState;
end

if r3 > maxState
    r3 = r3 - S(3,1) + maxState;
end

si = 1 + r3 + r2*N1 + r1*N1^2 + c3*N1^3 + c2*N1^4 + c1*N1^5;

if si > (2*(maxState+1))^(2*3)
    fprintf('bad state %d %d %d %d %d %d %d\n', si, c1, c2, c3, r1, r2, r3);
end



