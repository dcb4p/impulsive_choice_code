clear;

theta = 0 : 0.001 : 1;

a1 = .1;
a2 = 4;
    
pdist1 = (theta.^a1).*((1-theta).^(a1));
pdist2 = (theta.^a2).*((1-theta).^(a2));

pdist1 = pdist1/sum(pdist1);
pdist2 = pdist2/sum(pdist2);


cpdist1 = cumsum(pdist1);
cpdist2 = cumsum(pdist2);

N = 300;
nIter = 20;
mn = zeros(4,nIter);

for iter = 1 : nIter

    rr1v = rand(N+3, 1);
    rr2v = rand(N+3, 1);

    rr1 = zeros(N+3, 1);
    rr2 = zeros(N+3, 1);

    for ni = 1 : N+3

        [~, rr1i] = min(abs(rr1v(ni) - cpdist1));
        [~, rr2i] = min(abs(rr2v(ni) - cpdist2));

        rr1(ni) = theta(rr1i);    
        rr2(ni) = theta(rr2i);    

    end

    dropIn = randperm(N*20);
    choiceReplace = floor(3*rand(N, 1)) + 1;

    novelOption = zeros(N*20, 1);
    R1 = zeros(N*20, 1);
    R2 = zeros(N*20, 1);

    for noveli = 1 : N

        novelOption(dropIn(noveli), choiceReplace(noveli)) = 1;

    end

    novelTrial = sum(novelOption, 2);
    dropI = find(novelTrial == 1);

    rrc(1,1) = rr1(end-2);
    rrc(1,2) = rr1(end-1);
    rrc(1,3) = rr1(end);

    rrc(2,1) = rr2(end-2);
    rrc(2,2) = rr2(end-1);
    rrc(2,3) = rr2(end);

    ti = 1;
    for ni = 1 : N

        te = dropI(ni);

        Nt = (te - ti) + 1;

        for ci = 1 : 3
            for ri = 1 : 2
                n1s = round(Nt*rrc(ri, ci));
                rw = [ones(1, n1s) zeros(1, Nt - n1s)];

                rperm = randperm(Nt);

                rw = rw(rperm);

                if ri == 1
                    R1(ti:te, ci) = rw;
                else
                    R2(ti:te, ci) = rw;
                end

            end
        end

        ti = te + 1;

        qi = find(novelOption(ni, :) == 1);

        rrc(1, qi) = rr1(ni);
        rrc(2, qi) = rr2(ni);

    end

%     mean(R1)
%     mean(R2)

    %%% broad prior (high uncertainty)
    
    parfor mdpLoop = 1 : 4
        
        if mdpLoop == 1
            Rin = R1;
            policy = 1;
        elseif mdpLoop == 2
            Rin = R2;
            policy = 1;
        elseif mdpLoop == 3
            Rin = R1;
            policy = 3;
        else
            Rin = R2;
            policy = 3;
        end
                       
        [~, ~, rewards, ~] = mdpChoice_appx_ratio(policy, Rin, novelOption);    
    
        mn(mdpLoop, iter) = mean(rewards);
    end
    
    
end

subplot(2,2,1);
plot(theta, pdist1, theta, pdist2);

subplot(2,2,2);
hist(rr1);

subplot(2,2,3);
hist(rr2);

mna = mean(mn, 2)

subplot(2,2,4);
bar(mna');
axis([0.5 2.5 0.3 1]);
set(gca, 'XTickLabel', {'Broad Rewards', 'Narrow Rewards'});
legend('Broad Policy', 'Narrow Policy');

